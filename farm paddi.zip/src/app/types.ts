// Type definitions for FarmPaddi app

export interface User {
  id: string;
  fullName: string;
  email?: string;
  phone?: string;
  farmLocation: {
    state: string;
    lga: string;
  };
  farmSize: string;
  farmingType: 'Manual' | 'Mechanized';
  farmingMethod: 'Organic' | 'Inorganic' | 'Integrated';
}

export interface Crop {
  id: string;
  userId: string;
  cropName: string;
  variety: string;
  datePlanted: string;
  currentStage: string;
  daysToHarvest: number;
  soilType: string;
  farmSize: string;
  plantingMethod: string;
  irrigationType: string;
  farmingType: 'Manual' | 'Mechanized';
  farmingMethod: 'Organic' | 'Inorganic' | 'Integrated';
  expectedHarvestDate: string;
  isActive: boolean;
  recommendations?: {
    spacing: string;
    maturityPeriod: string;
    fertilizerPlan: string;
    harvestWindow: string;
    keyPractices: string[];
  };
}

export interface Activity {
  id: string;
  cropId: string;
  userId: string;
  date: string;
  activityType: 'Planting' | 'Weeding' | 'Fertilizer' | 'Pest Control' | 'Irrigation' | 'Harvest' | 'Other';
  quantityUsed?: string;
  cost?: number;
  notes?: string;
  completed: boolean;
}

export interface Expense {
  id: string;
  userId: string;
  cropId?: string;
  date: string;
  category: 'Seeds' | 'Fertilizer' | 'Pesticides' | 'Labour' | 'Transport' | 'Equipment' | 'Other';
  description: string;
  amount: number;
}

export interface Income {
  id: string;
  userId: string;
  cropId: string;
  date: string;
  harvestQuantity: string;
  sellingPrice: number;
  totalRevenue: number;
}

export interface CropInfo {
  name: string;
  description: string;
  varieties: string[];
  soilRequirements: string;
  climateRequirements: string;
  farmingGuide: string[];
  commonPests: string[];
  controlMethods: string[];
  maturityPeriodDays: number;
}
