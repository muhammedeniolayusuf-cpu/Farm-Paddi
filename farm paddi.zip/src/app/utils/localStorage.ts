// LocalStorage utilities for data persistence
import type { User, Crop, Activity, Expense, Income } from '../types';

const STORAGE_KEYS = {
  USER: 'farmpaddi_user',
  USERS: 'farmpaddi_users',
  CROPS: 'farmpaddi_crops',
  ACTIVITIES: 'farmpaddi_activities',
  EXPENSES: 'farmpaddi_expenses',
  INCOME: 'farmpaddi_income',
};

// User Management
export const saveUser = (user: User): void => {
  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
};

export const getUser = (): User | null => {
  const user = localStorage.getItem(STORAGE_KEYS.USER);
  return user ? JSON.parse(user) : null;
};

export const clearUser = (): void => {
  localStorage.removeItem(STORAGE_KEYS.USER);
};

// Users Database (for authentication)
export const getAllUsers = (): Array<User & { password: string }> => {
  const users = localStorage.getItem(STORAGE_KEYS.USERS);
  return users ? JSON.parse(users) : [];
};

export const createUser = (user: User & { password: string }): void => {
  const users = getAllUsers();
  users.push(user);
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
};

export const authenticateUser = (emailOrPhone: string, password: string): User | null => {
  const users = getAllUsers();
  const user = users.find(
    (u) => (u.email === emailOrPhone || u.phone === emailOrPhone) && u.password === password
  );
  return user ? { ...user, password: undefined } as any : null;
};

// Crop Management
export const getCrops = (userId: string): Crop[] => {
  const crops = localStorage.getItem(STORAGE_KEYS.CROPS);
  const allCrops: Crop[] = crops ? JSON.parse(crops) : [];
  return allCrops.filter((crop) => crop.userId === userId);
};

export const saveCrop = (crop: Crop): void => {
  const crops = localStorage.getItem(STORAGE_KEYS.CROPS);
  const allCrops: Crop[] = crops ? JSON.parse(crops) : [];
  const existingIndex = allCrops.findIndex((c) => c.id === crop.id);
  
  if (existingIndex >= 0) {
    allCrops[existingIndex] = crop;
  } else {
    allCrops.push(crop);
  }
  
  localStorage.setItem(STORAGE_KEYS.CROPS, JSON.stringify(allCrops));
};

export const deleteCrop = (cropId: string): void => {
  const crops = localStorage.getItem(STORAGE_KEYS.CROPS);
  const allCrops: Crop[] = crops ? JSON.parse(crops) : [];
  const filtered = allCrops.filter((c) => c.id !== cropId);
  localStorage.setItem(STORAGE_KEYS.CROPS, JSON.stringify(filtered));
};

// Activity Management
export const getActivities = (userId: string, cropId?: string): Activity[] => {
  const activities = localStorage.getItem(STORAGE_KEYS.ACTIVITIES);
  const allActivities: Activity[] = activities ? JSON.parse(activities) : [];
  return allActivities.filter(
    (activity) => activity.userId === userId && (!cropId || activity.cropId === cropId)
  );
};

export const saveActivity = (activity: Activity): void => {
  const activities = localStorage.getItem(STORAGE_KEYS.ACTIVITIES);
  const allActivities: Activity[] = activities ? JSON.parse(activities) : [];
  const existingIndex = allActivities.findIndex((a) => a.id === activity.id);
  
  if (existingIndex >= 0) {
    allActivities[existingIndex] = activity;
  } else {
    allActivities.push(activity);
  }
  
  localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(allActivities));
};

// Expense Management
export const getExpenses = (userId: string, cropId?: string): Expense[] => {
  const expenses = localStorage.getItem(STORAGE_KEYS.EXPENSES);
  const allExpenses: Expense[] = expenses ? JSON.parse(expenses) : [];
  return allExpenses.filter(
    (expense) => expense.userId === userId && (!cropId || expense.cropId === cropId)
  );
};

export const saveExpense = (expense: Expense): void => {
  const expenses = localStorage.getItem(STORAGE_KEYS.EXPENSES);
  const allExpenses: Expense[] = expenses ? JSON.parse(expenses) : [];
  const existingIndex = allExpenses.findIndex((e) => e.id === expense.id);
  
  if (existingIndex >= 0) {
    allExpenses[existingIndex] = expense;
  } else {
    allExpenses.push(expense);
  }
  
  localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(allExpenses));
};

// Income Management
export const getIncome = (userId: string, cropId?: string): Income[] => {
  const income = localStorage.getItem(STORAGE_KEYS.INCOME);
  const allIncome: Income[] = income ? JSON.parse(income) : [];
  return allIncome.filter(
    (inc) => inc.userId === userId && (!cropId || inc.cropId === cropId)
  );
};

export const saveIncome = (income: Income): void => {
  const allIncome = localStorage.getItem(STORAGE_KEYS.INCOME);
  const incomeArray: Income[] = allIncome ? JSON.parse(allIncome) : [];
  const existingIndex = incomeArray.findIndex((i) => i.id === income.id);
  
  if (existingIndex >= 0) {
    incomeArray[existingIndex] = income;
  } else {
    incomeArray.push(income);
  }
  
  localStorage.setItem(STORAGE_KEYS.INCOME, JSON.stringify(incomeArray));
};
