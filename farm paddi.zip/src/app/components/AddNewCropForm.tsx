import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent } from './ui/card';
import { auth, crops as cropsApi } from '../utils/supabase';
import { NIGERIAN_CROPS, getCropByName } from '../data/crops';
import { toast } from 'sonner';
import type { Crop } from '../types';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';

interface AddNewCropFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const PLANTING_METHODS = ['Broadcasting', 'Transplanting', 'Drilling', 'Dibbling', 'Ridge planting'];
const IRRIGATION_TYPES = ['Rainfed', 'Drip irrigation', 'Sprinkler', 'Flood irrigation', 'Manual watering'];
const SOIL_TYPES = ['Sandy', 'Clay', 'Loamy', 'Sandy Loam', 'Clay Loam', 'Silty'];

export function AddNewCropForm({ onSuccess, onCancel }: AddNewCropFormProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    cropName: '',
    variety: '',
    soilType: '',
    farmSize: '',
    plantingMethod: '',
    irrigationType: '',
    farmingType: 'Manual' as 'Manual' | 'Mechanized',
    farmingMethod: 'Integrated' as 'Organic' | 'Inorganic' | 'Integrated',
    datePlanted: new Date().toISOString().split('T')[0],
  });

  const selectedCropInfo = formData.cropName ? getCropByName(formData.cropName) : null;

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (step === 1 && !formData.cropName) {
      toast.error('Please select a crop');
      return;
    }
    if (step === 2 && !formData.variety) {
      toast.error('Please select a variety');
      return;
    }
    if (step === 3) {
      if (!formData.soilType || !formData.farmSize || !formData.plantingMethod || !formData.irrigationType) {
        toast.error('Please fill all farm information');
        return;
      }
    }
    setStep(step + 1);
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const handleSubmit = async () => {
    try {
      const profile = await auth.getProfile();
      if (!profile || !selectedCropInfo) return;

      const expectedHarvestDate = new Date();
      expectedHarvestDate.setDate(expectedHarvestDate.getDate() + selectedCropInfo.maturityPeriodDays);

      const crop: Crop = {
        id: Date.now().toString(),
        userId: profile.id,
        cropName: formData.cropName,
        variety: formData.variety,
        datePlanted: formData.datePlanted,
        currentStage: 'Germination',
        daysToHarvest: selectedCropInfo.maturityPeriodDays,
        soilType: formData.soilType,
        farmSize: formData.farmSize,
        plantingMethod: formData.plantingMethod,
        irrigationType: formData.irrigationType,
        farmingType: formData.farmingType,
        farmingMethod: formData.farmingMethod,
        expectedHarvestDate: expectedHarvestDate.toISOString().split('T')[0],
        isActive: true,
        recommendations: {
          spacing: selectedCropInfo.soilRequirements,
          maturityPeriod: `${selectedCropInfo.maturityPeriodDays} days`,
          fertilizerPlan: 'Apply NPK fertilizer at planting, 4 weeks, and 8 weeks after planting',
          harvestWindow: `Expected harvest around ${expectedHarvestDate.toLocaleDateString('en-NG')}`,
          keyPractices: selectedCropInfo.farmingGuide.slice(0, 5),
        },
      };

      await cropsApi.save(crop);
      toast.success('Crop added successfully!');
      onSuccess();
    } catch (error: any) {
      console.error('Error saving crop:', error);
      toast.error(error.message || 'Failed to save crop');
    }
  };

  return (
    <div className="space-y-6">
      {/* Progress indicator */}
      <div className="flex items-center justify-between">
        {[1, 2, 3, 4, 5].map((s) => (
          <div key={s} className="flex items-center flex-1">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                s <= step ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-600'
              }`}
            >
              {s < step ? <Check className="w-5 h-5" /> : s}
            </div>
            {s < 5 && <div className={`flex-1 h-1 mx-1 ${s < step ? 'bg-green-600' : 'bg-gray-200'}`} />}
          </div>
        ))}
      </div>

      {/* Step 1: Select Crop */}
      {step === 1 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-green-800">Step 1: Select Crop</h3>
          <div className="grid grid-cols-2 gap-3 max-h-96 overflow-y-auto">
            {NIGERIAN_CROPS.map((crop) => (
              <Card
                key={crop.name}
                className={`cursor-pointer transition-all ${
                  formData.cropName === crop.name
                    ? 'border-2 border-green-600 bg-green-50'
                    : 'border border-gray-300 hover:border-green-400'
                }`}
                onClick={() => handleChange('cropName', crop.name)}
              >
                <CardContent className="p-4">
                  <h4 className="font-semibold text-green-800">{crop.name}</h4>
                  <p className="text-xs text-gray-600 mt-1 line-clamp-2">{crop.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Step 2: Select Variety */}
      {step === 2 && selectedCropInfo && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-green-800">Step 2: Select Variety</h3>
          <p className="text-sm text-gray-600">Choose a {formData.cropName} variety</p>
          <div className="grid grid-cols-1 gap-3">
            {selectedCropInfo.varieties.map((variety) => (
              <Card
                key={variety}
                className={`cursor-pointer transition-all ${
                  formData.variety === variety
                    ? 'border-2 border-green-600 bg-green-50'
                    : 'border border-gray-300 hover:border-green-400'
                }`}
                onClick={() => handleChange('variety', variety)}
              >
                <CardContent className="p-4">
                  <p className="font-medium text-green-800">{variety}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Step 3: Farm Information */}
      {step === 3 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-green-800">Step 3: Farm Information</h3>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Soil Type</Label>
              <Select value={formData.soilType} onValueChange={(value) => handleChange('soilType', value)}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select soil type" />
                </SelectTrigger>
                <SelectContent>
                  {SOIL_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Farm Size for this Crop</Label>
              <Input
                placeholder="e.g., 0.5 hectares, 2 acres, 5 plots"
                value={formData.farmSize}
                onChange={(e) => handleChange('farmSize', e.target.value)}
                className="h-12"
              />
            </div>

            <div className="space-y-2">
              <Label>Planting Method</Label>
              <Select value={formData.plantingMethod} onValueChange={(value) => handleChange('plantingMethod', value)}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select planting method" />
                </SelectTrigger>
                <SelectContent>
                  {PLANTING_METHODS.map((method) => (
                    <SelectItem key={method} value={method}>{method}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Irrigation Type</Label>
              <Select value={formData.irrigationType} onValueChange={(value) => handleChange('irrigationType', value)}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select irrigation type" />
                </SelectTrigger>
                <SelectContent>
                  {IRRIGATION_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Farming Type</Label>
                <Select value={formData.farmingType} onValueChange={(value: any) => handleChange('farmingType', value)}>
                  <SelectTrigger className="h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Manual">Manual</SelectItem>
                    <SelectItem value="Mechanized">Mechanized</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Farming Method</Label>
                <Select value={formData.farmingMethod} onValueChange={(value: any) => handleChange('farmingMethod', value)}>
                  <SelectTrigger className="h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Organic">Organic</SelectItem>
                    <SelectItem value="Inorganic">Inorganic</SelectItem>
                    <SelectItem value="Integrated">Integrated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 4: Planting Date */}
      {step === 4 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-green-800">Step 4: Planting Date</h3>
          <div className="space-y-2">
            <Label>When did you plant or when will you plant?</Label>
            <Input
              type="date"
              value={formData.datePlanted}
              onChange={(e) => handleChange('datePlanted', e.target.value)}
              className="h-12"
              max={new Date().toISOString().split('T')[0]}
            />
          </div>
        </div>
      )}

      {/* Step 5: Recommendations */}
      {step === 5 && selectedCropInfo && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-green-800">Step 5: System Recommendations</h3>
          <Card className="border-2 border-green-600 bg-green-50">
            <CardContent className="p-4 space-y-4">
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Maturity Period</h4>
                <p className="text-sm">{selectedCropInfo.maturityPeriodDays} days</p>
              </div>
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Soil Requirements</h4>
                <p className="text-sm">{selectedCropInfo.soilRequirements}</p>
              </div>
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Climate Requirements</h4>
                <p className="text-sm">{selectedCropInfo.climateRequirements}</p>
              </div>
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Key Management Practices</h4>
                <ul className="text-sm space-y-1 list-disc list-inside">
                  {selectedCropInfo.farmingGuide.slice(0, 5).map((practice, idx) => (
                    <li key={idx}>{practice}</li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Navigation buttons */}
      <div className="flex justify-between pt-4">
        {step > 1 ? (
          <Button variant="outline" onClick={handleBack} className="border-green-600 text-green-700">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        ) : (
          <Button variant="outline" onClick={onCancel} className="border-gray-300">
            Cancel
          </Button>
        )}
        
        {step < 5 ? (
          <Button onClick={handleNext} className="bg-green-600 hover:bg-green-700">
            Next
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        ) : (
          <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
            <Check className="w-4 h-4 mr-2" />
            Save Crop
          </Button>
        )}
      </div>
    </div>
  );
}