import { Outlet } from 'react-router';
import { BottomNav } from './BottomNav';

export function DashboardLayout() {
  return (
    <div className="min-h-screen bg-green-50 pb-20">
      <Outlet />
      <BottomNav />
    </div>
  );
}