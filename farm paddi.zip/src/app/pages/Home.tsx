import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Plus, User, Bell, Calendar, Leaf, LogOut } from 'lucide-react';
import { auth, crops as cropsApi, activities as activitiesApi } from '../utils/supabase';
import type { User as UserType, Crop, Activity } from '../types';
import { AddCropDialog } from '../components/AddCropDialog';
import { toast } from 'sonner';

export function Home() {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserType | null>(null);
  const [crops, setCrops] = useState<Crop[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [showAddCrop, setShowAddCrop] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const profile = await auth.getProfile();
      if (!profile) {
        navigate('/login');
        return;
      }
      setUser(profile);

      const [userCrops, userActivities] = await Promise.all([
        cropsApi.getAll(),
        activitiesApi.getAll(),
      ]);

      setCrops(userCrops);
      setActivities(userActivities);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const activeCrops = crops.filter(c => c.isActive);
  const upcomingTasks = activities.filter(a => !a.completed).length;

  const calculateDaysToHarvest = (expectedDate: string): number => {
    const today = new Date();
    const harvest = new Date(expectedDate);
    const diffTime = harvest.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const getStageColor = (stage: string): string => {
    switch (stage.toLowerCase()) {
      case 'germination':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'vegetative':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'flowering':
        return 'bg-pink-100 text-pink-800 border-pink-300';
      case 'fruiting':
        return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'maturity':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const handleRefresh = async () => {
    try {
      const [userCrops, userActivities] = await Promise.all([
        cropsApi.getAll(),
        activitiesApi.getAll(),
      ]);
      setCrops(userCrops);
      setActivities(userActivities);
    } catch (error) {
      console.error('Error refreshing data:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-green-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-sm opacity-90">Welcome back,</p>
            <h1 className="text-2xl font-semibold mt-1">{user?.fullName}</h1>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="ghost" 
              size="icon"
              className="text-white hover:bg-green-700"
            >
              <Bell className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              className="text-white hover:bg-green-700"
              onClick={async () => {
                try {
                  await auth.signOut();
                  toast.success('Logged out successfully');
                  navigate('/login');
                } catch (error) {
                  console.error('Logout error:', error);
                  toast.error('Failed to logout');
                }
              }}
            >
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
        <p className="text-sm opacity-90">{new Date().toLocaleDateString('en-NG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>

      {/* Farm Summary */}
      <div className="px-4 py-6 space-y-4">
        <h2 className="text-xl font-semibold text-green-800">Farm Summary</h2>
        <div className="grid grid-cols-3 gap-3">
          <Card className="border-2 border-green-200">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-green-700">{crops.length}</div>
              <div className="text-sm text-gray-600 mt-1">Total Crops</div>
            </CardContent>
          </Card>
          <Card className="border-2 border-green-200">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-green-700">{activeCrops.length}</div>
              <div className="text-sm text-gray-600 mt-1">Active Crops</div>
            </CardContent>
          </Card>
          <Card className="border-2 border-green-200">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-green-700">{upcomingTasks}</div>
              <div className="text-sm text-gray-600 mt-1">Pending Tasks</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* My Crops */}
      <div className="px-4 pb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-green-800">My Crops</h2>
          {crops.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              className="text-green-700"
            >
              Refresh
            </Button>
          )}
        </div>

        {crops.length === 0 ? (
          <Card className="border-2 border-dashed border-green-300">
            <CardContent className="p-8 text-center">
              <Leaf className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700 mb-2">No crops yet</h3>
              <p className="text-gray-600 mb-4">Start your farming journey by adding your first crop</p>
              <Button 
                onClick={() => setShowAddCrop(true)}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Your First Crop
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {crops.map((crop) => {
              const daysLeft = calculateDaysToHarvest(crop.expectedHarvestDate);
              return (
                <Card 
                  key={crop.id}
                  className="border-2 border-green-300 hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => navigate(`/dashboard/crop/${crop.id}`)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="text-lg font-semibold text-green-800">{crop.cropName}</h3>
                        <p className="text-sm text-gray-600">{crop.variety}</p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full border ${getStageColor(crop.currentStage)}`}>
                        {crop.currentStage}
                      </span>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center text-gray-700">
                        <Calendar className="w-4 h-4 mr-2 text-green-600" />
                        <span>Planted: {new Date(crop.datePlanted).toLocaleDateString('en-NG')}</span>
                      </div>
                      <div className="flex items-center font-semibold text-green-700">
                        <span className="text-2xl mr-2">{daysLeft}</span>
                        <span>days to harvest</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Action Button */}
      {crops.length > 0 && (
        <Button
          onClick={() => setShowAddCrop(true)}
          className="fixed bottom-24 right-4 w-14 h-14 rounded-full bg-green-600 hover:bg-green-700 shadow-lg"
          size="icon"
        >
          <Plus className="w-6 h-6" />
        </Button>
      )}

      <AddCropDialog 
        open={showAddCrop} 
        onOpenChange={setShowAddCrop}
        onSuccess={handleRefresh}
      />
    </div>
  );
}