import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { auth } from '../utils/supabase';
import { toast } from 'sonner';
import { Sprout } from 'lucide-react';

export function Login() {
  const navigate = useNavigate();
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await auth.signIn(emailOrPhone, password);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error(error.message || 'Invalid email/phone or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-green-600 shadow-xl">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-green-600 p-4 rounded-full">
              <Sprout className="w-12 h-12 text-white" />
            </div>
          </div>
          <CardTitle className="text-3xl text-green-800">Welcome to FarmPaddi</CardTitle>
          <CardDescription className="text-base">Farming Made Easy</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="emailOrPhone" className="text-base">Phone Number or Email</Label>
              <Input
                id="emailOrPhone"
                type="text"
                placeholder="Enter your phone or email"
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                required
                className="h-12 text-base border-green-300 focus:border-green-600"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-base">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-12 text-base border-green-300 focus:border-green-600"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full h-12 text-base bg-green-600 hover:bg-green-700"
              disabled={loading}
            >
              {loading ? 'Logging in...' : 'Login'}
            </Button>
            <div className="text-center pt-2">
              <Button
                type="button"
                variant="link"
                className="text-green-700 hover:text-green-800"
                onClick={() => navigate('/signup')}
              >
                Don't have an account? Create Account
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}