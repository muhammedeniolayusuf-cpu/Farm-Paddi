import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { ArrowLeft, Calendar, Droplet, MapPin, CheckCircle2, Circle, Plus } from 'lucide-react';
import { getCrops, getActivities, saveActivity } from '../utils/localStorage';
import { getCropByName } from '../data/crops';
import type { Crop, Activity } from '../types';
import { LogActivityDialog } from '../components/LogActivityDialog';

export function CropDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [crop, setCrop] = useState<Crop | null>(null);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [showLogActivity, setShowLogActivity] = useState(false);

  useEffect(() => {
    if (id) {
      const allCrops = getCrops('');
      const foundCrop = allCrops.find(c => c.id === id);
      if (foundCrop) {
        setCrop(foundCrop);
        setActivities(getActivities(foundCrop.userId, id));
      }
    }
  }, [id]);

  if (!crop) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Crop not found</p>
      </div>
    );
  }

  const cropInfo = getCropByName(crop.cropName);
  const daysElapsed = Math.floor((new Date().getTime() - new Date(crop.datePlanted).getTime()) / (1000 * 60 * 60 * 24));
  const completedActivities = activities.filter(a => a.completed).length;
  const totalActivities = activities.length;

  const handleActivityToggle = (activity: Activity) => {
    const updated = { ...activity, completed: !activity.completed };
    saveActivity(updated);
    setActivities(prev => prev.map(a => a.id === activity.id ? updated : a));
  };

  const handleRefresh = () => {
    if (id) {
      setActivities(getActivities(crop.userId, id));
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/dashboard')}
          className="text-white hover:bg-green-700 mb-4"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Dashboard
        </Button>
        <h1 className="text-2xl font-semibold">{crop.cropName}</h1>
        <p className="text-sm opacity-90 mt-1">{crop.variety}</p>
      </div>

      <div className="px-4 py-6 space-y-6">
        {/* Crop Overview */}
        <Card className="border-2 border-green-600">
          <CardContent className="p-4 space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-lg font-semibold text-green-800">Crop Overview</h2>
              </div>
              <span className="text-xs px-3 py-1 rounded-full bg-green-100 text-green-800 border border-green-300">
                {crop.currentStage}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Planted Date</p>
                <p className="font-semibold">{new Date(crop.datePlanted).toLocaleDateString('en-NG')}</p>
              </div>
              <div>
                <p className="text-gray-600">Expected Harvest</p>
                <p className="font-semibold">{new Date(crop.expectedHarvestDate).toLocaleDateString('en-NG')}</p>
              </div>
              <div>
                <p className="text-gray-600">Days Elapsed</p>
                <p className="font-semibold">{daysElapsed} days</p>
              </div>
              <div>
                <p className="text-gray-600">Days to Harvest</p>
                <p className="font-semibold text-green-700">{crop.daysToHarvest} days</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Farm Details */}
        <Card className="border-green-200">
          <CardContent className="p-4 space-y-3">
            <h3 className="text-lg font-semibold text-green-800">Farm Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-start">
                <MapPin className="w-4 h-4 mr-2 text-green-600 mt-0.5" />
                <div>
                  <p className="font-medium">Farm Size</p>
                  <p className="text-gray-600">{crop.farmSize}</p>
                </div>
              </div>
              <div className="flex items-start">
                <Droplet className="w-4 h-4 mr-2 text-green-600 mt-0.5" />
                <div>
                  <p className="font-medium">Soil Type</p>
                  <p className="text-gray-600">{crop.soilType}</p>
                </div>
              </div>
              <div className="flex items-start">
                <Calendar className="w-4 h-4 mr-2 text-green-600 mt-0.5" />
                <div>
                  <p className="font-medium">Planting Method</p>
                  <p className="text-gray-600">{crop.plantingMethod}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recommendations */}
        {crop.recommendations && (
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4 space-y-3">
              <h3 className="text-lg font-semibold text-green-800">Recommendations</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="font-medium text-green-800">Maturity Period</p>
                  <p className="text-gray-700">{crop.recommendations.maturityPeriod}</p>
                </div>
                <div>
                  <p className="font-medium text-green-800">Key Practices</p>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 mt-1">
                    {crop.recommendations.keyPractices.map((practice, idx) => (
                      <li key={idx} className="text-xs">{practice}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Task Tracker */}
        <Card className="border-green-200">
          <CardContent className="p-4 space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-green-800">Tasks</h3>
              <span className="text-sm text-gray-600">
                {completedActivities}/{totalActivities} completed
              </span>
            </div>
            
            {activities.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p className="mb-4">No tasks yet</p>
                <Button
                  onClick={() => setShowLogActivity(true)}
                  variant="outline"
                  className="border-green-600 text-green-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Task
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {activities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start p-3 rounded-lg border border-gray-200 hover:bg-gray-50 cursor-pointer"
                    onClick={() => handleActivityToggle(activity)}
                  >
                    {activity.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-gray-400 mr-3 mt-0.5 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <p className={`font-medium ${activity.completed ? 'text-gray-500 line-through' : 'text-gray-800'}`}>
                        {activity.activityType}
                      </p>
                      <p className="text-xs text-gray-600 mt-1">
                        {new Date(activity.date).toLocaleDateString('en-NG')}
                        {activity.notes && ` • ${activity.notes}`}
                      </p>
                    </div>
                    {activity.cost && (
                      <p className="text-sm font-medium text-green-700">₦{activity.cost.toLocaleString()}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Farming Guide */}
        {cropInfo && (
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4 space-y-3">
              <h3 className="text-lg font-semibold text-blue-800">Farming Guide</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="font-medium text-blue-800">Common Pests & Diseases</p>
                  <p className="text-gray-700">{cropInfo.commonPests.join(', ')}</p>
                </div>
                <div>
                  <p className="font-medium text-blue-800">Control Methods</p>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 mt-1">
                    {cropInfo.controlMethods.map((method, idx) => (
                      <li key={idx} className="text-xs">{method}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Log Activity Button */}
        <Button
          onClick={() => setShowLogActivity(true)}
          className="w-full h-12 bg-green-600 hover:bg-green-700"
        >
          <Plus className="w-5 h-5 mr-2" />
          Log Activity
        </Button>
      </div>

      <LogActivityDialog
        open={showLogActivity}
        onOpenChange={setShowLogActivity}
        cropId={crop.id}
        userId={crop.userId}
        onSuccess={handleRefresh}
      />
    </div>
  );
}
