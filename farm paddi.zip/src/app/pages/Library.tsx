import { useState } from 'react';
import { Card, CardContent } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Search, Book } from 'lucide-react';
import { NIGERIAN_CROPS, searchCrops } from '../data/crops';
import { CropInfoDialog } from '../components/CropInfoDialog';
import type { CropInfo } from '../types';

export function Library() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCrop, setSelectedCrop] = useState<CropInfo | null>(null);
  
  const filteredCrops = searchQuery ? searchCrops(searchQuery) : NIGERIAN_CROPS;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-6">
        <h1 className="text-2xl font-semibold">Library</h1>
        <p className="text-sm opacity-90 mt-1">Crop knowledge database</p>
      </div>

      {/* Search Bar */}
      <div className="px-4 py-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            type="text"
            placeholder="Search for crops..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12 text-base border-green-300 focus:border-green-600"
          />
        </div>
      </div>

      {/* Crop Cards */}
      <div className="px-4 pb-6">
        {filteredCrops.length === 0 ? (
          <Card className="border-dashed border-2 border-gray-300">
            <CardContent className="p-8 text-center">
              <Book className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No crops found matching "{searchQuery}"</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredCrops.map((crop) => (
              <Card
                key={crop.name}
                className="border-2 border-green-300 hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedCrop(crop)}
              >
                <CardContent className="p-4">
                  <h3 className="text-lg font-semibold text-green-800 mb-2">{crop.name}</h3>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">{crop.description}</p>
                  <div className="flex flex-wrap gap-2">
                    <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">
                      {crop.maturityPeriodDays} days
                    </span>
                    <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                      {crop.varieties.length} varieties
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <CropInfoDialog
        crop={selectedCrop}
        open={!!selectedCrop}
        onOpenChange={(open) => !open && setSelectedCrop(null)}
      />
    </div>
  );
}
