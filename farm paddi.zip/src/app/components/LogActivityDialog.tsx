import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { saveActivity } from '../utils/localStorage';
import { toast } from 'sonner';
import type { Activity } from '../types';

interface LogActivityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cropId: string;
  userId: string;
  onSuccess: () => void;
}

const ACTIVITY_TYPES: Activity['activityType'][] = [
  'Planting',
  'Weeding',
  'Fertilizer',
  'Pest Control',
  'Irrigation',
  'Harvest',
  'Other'
];

export function LogActivityDialog({ open, onOpenChange, cropId, userId, onSuccess }: LogActivityDialogProps) {
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    activityType: 'Weeding' as Activity['activityType'],
    quantityUsed: '',
    cost: '',
    notes: '',
  });

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const activity: Activity = {
      id: Date.now().toString(),
      cropId,
      userId,
      date: formData.date,
      activityType: formData.activityType,
      quantityUsed: formData.quantityUsed || undefined,
      cost: formData.cost ? parseFloat(formData.cost) : undefined,
      notes: formData.notes || undefined,
      completed: false,
    };

    saveActivity(activity);
    toast.success('Activity logged successfully!');
    
    // Reset form
    setFormData({
      date: new Date().toISOString().split('T')[0],
      activityType: 'Weeding',
      quantityUsed: '',
      cost: '',
      notes: '',
    });
    
    onSuccess();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl text-green-800">Log Activity</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Date *</Label>
            <Input
              type="date"
              value={formData.date}
              onChange={(e) => handleChange('date', e.target.value)}
              max={new Date().toISOString().split('T')[0]}
              required
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Activity Type *</Label>
            <Select value={formData.activityType} onValueChange={(value: Activity['activityType']) => handleChange('activityType', value)} required>
              <SelectTrigger className="h-12">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ACTIVITY_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Quantity Used (Optional)</Label>
            <Input
              placeholder="e.g., 2 bags, 5 liters"
              value={formData.quantityUsed}
              onChange={(e) => handleChange('quantityUsed', e.target.value)}
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Cost (₦) (Optional)</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="Enter amount"
              value={formData.cost}
              onChange={(e) => handleChange('cost', e.target.value)}
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Notes (Optional)</Label>
            <Textarea
              placeholder="Add any additional notes..."
              value={formData.notes}
              onChange={(e) => handleChange('notes', e.target.value)}
              className="min-h-20"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              Save Activity
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
