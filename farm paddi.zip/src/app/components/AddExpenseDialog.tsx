import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { auth, expenses as expensesApi, crops as cropsApi } from '../utils/supabase';
import { toast } from 'sonner';
import type { Expense, Crop } from '../types';

interface AddExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

const EXPENSE_CATEGORIES: Expense['category'][] = [
  'Seeds',
  'Fertilizer',
  'Pesticides',
  'Labour',
  'Transport',
  'Equipment',
  'Other'
];

export function AddExpenseDialog({ open, onOpenChange, onSuccess }: AddExpenseDialogProps) {
  const [crops, setCrops] = useState<Crop[]>([]);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    category: 'Seeds' as Expense['category'],
    description: '',
    amount: '',
    cropId: '',
  });

  useEffect(() => {
    loadCrops();
  }, []);

  const loadCrops = async () => {
    try {
      const userCrops = await cropsApi.getAll();
      setCrops(userCrops);
    } catch (error) {
      console.error('Error loading crops:', error);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.description || !formData.amount) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      const profile = await auth.getProfile();
      if (!profile) return;

      const expense: Expense = {
        id: Date.now().toString(),
        userId: profile.id,
        cropId: formData.cropId || undefined,
        date: formData.date,
        category: formData.category,
        description: formData.description,
        amount: parseFloat(formData.amount),
      };

      await expensesApi.save(expense);
      toast.success('Expense recorded successfully!');
      onSuccess();
      onOpenChange(false);
      // Reset form
      setFormData({
        date: new Date().toISOString().split('T')[0],
        category: 'Seeds',
        description: '',
        amount: '',
        cropId: '',
      });
    } catch (error: any) {
      console.error('Error saving expense:', error);
      toast.error(error.message || 'Failed to save expense');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl text-green-800">Add Expense</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Date *</Label>
            <Input
              type="date"
              value={formData.date}
              onChange={(e) => handleChange('date', e.target.value)}
              max={new Date().toISOString().split('T')[0]}
              required
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Category *</Label>
            <Select value={formData.category} onValueChange={(value: Expense['category']) => handleChange('category', value)} required>
              <SelectTrigger className="h-12">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {EXPENSE_CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Description *</Label>
            <Input
              placeholder="e.g., Purchased tomato seeds"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              required
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Amount (₦) *</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="Enter amount"
              value={formData.amount}
              onChange={(e) => handleChange('amount', e.target.value)}
              required
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Related Crop (Optional)</Label>
            <Select value={formData.cropId} onValueChange={(value) => handleChange('cropId', value)}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Select crop (if applicable)" />
              </SelectTrigger>
              <SelectContent>
                {crops.map((crop) => (
                  <SelectItem key={crop.id} value={crop.id}>
                    {crop.cropName} - {crop.variety}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              Save Expense
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}