import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { auth } from '../utils/supabase';
import { toast } from 'sonner';
import { Sprout, ArrowLeft } from 'lucide-react';

const NIGERIAN_STATES = [
  'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa', 'Benue', 'Borno', 'Cross River',
  'Delta', 'Ebonyi', 'Edo', 'Ekiti', 'Enugu', 'Gombe', 'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina',
  'Kebbi', 'Kogi', 'Kwara', 'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun', 'Oyo', 'Plateau',
  'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara', 'FCT'
];

export function Signup() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    state: '',
    lga: '',
    farmSize: '',
    farmingType: 'Manual' as 'Manual' | 'Mechanized',
    farmingMethod: 'Integrated' as 'Organic' | 'Inorganic' | 'Integrated',
  });

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validation
      if (formData.password !== formData.confirmPassword) {
        toast.error('Passwords do not match');
        setLoading(false);
        return;
      }

      if (formData.password.length < 6) {
        toast.error('Password must be at least 6 characters');
        setLoading(false);
        return;
      }

      if (!formData.email && !formData.phone) {
        toast.error('Please provide either email or phone number');
        setLoading(false);
        return;
      }

      await auth.signUp({
        email: formData.email || undefined,
        phone: formData.phone || undefined,
        password: formData.password,
        fullName: formData.fullName,
        farmLocation: {
          state: formData.state,
          lga: formData.lga,
        },
        farmSize: formData.farmSize,
        farmingType: formData.farmingType,
        farmingMethod: formData.farmingMethod,
      });

      toast.success('Account created successfully!');
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Signup error:', error);
      toast.error(error.message || 'Failed to create account. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate('/login')}
          className="mb-4 text-green-700 hover:text-green-800"
        >
          <ArrowLeft className="mr-2 h-5 w-5" />
          Back to Login
        </Button>
        
        <Card className="border-2 border-green-600 shadow-xl">
          <CardHeader className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="bg-green-600 p-4 rounded-full">
                <Sprout className="w-12 h-12 text-white" />
              </div>
            </div>
            <CardTitle className="text-3xl text-green-800">Create Account</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-base">Full Name *</Label>
                <Input
                  id="fullName"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={(e) => handleChange('fullName', e.target.value)}
                  required
                  className="h-12 text-base border-green-300 focus:border-green-600"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-base">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    className="h-12 text-base border-green-300 focus:border-green-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-base">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="080XXXXXXXX"
                    value={formData.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    className="h-12 text-base border-green-300 focus:border-green-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-base">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Minimum 6 characters"
                    value={formData.password}
                    onChange={(e) => handleChange('password', e.target.value)}
                    required
                    className="h-12 text-base border-green-300 focus:border-green-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-base">Confirm Password *</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Re-enter password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleChange('confirmPassword', e.target.value)}
                    required
                    className="h-12 text-base border-green-300 focus:border-green-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="state" className="text-base">State *</Label>
                  <Select value={formData.state} onValueChange={(value) => handleChange('state', value)} required>
                    <SelectTrigger className="h-12 text-base border-green-300">
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      {NIGERIAN_STATES.map(state => (
                        <SelectItem key={state} value={state}>{state}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lga" className="text-base">Local Government *</Label>
                  <Input
                    id="lga"
                    placeholder="Enter LGA"
                    value={formData.lga}
                    onChange={(e) => handleChange('lga', e.target.value)}
                    required
                    className="h-12 text-base border-green-300 focus:border-green-600"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="farmSize" className="text-base">Farm Size *</Label>
                <Input
                  id="farmSize"
                  placeholder="e.g., 2 hectares, 5 acres, 3 plots"
                  value={formData.farmSize}
                  onChange={(e) => handleChange('farmSize', e.target.value)}
                  required
                  className="h-12 text-base border-green-300 focus:border-green-600"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="farmingType" className="text-base">Farming Type *</Label>
                  <Select value={formData.farmingType} onValueChange={(value: any) => handleChange('farmingType', value)} required>
                    <SelectTrigger className="h-12 text-base border-green-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Manual">Manual</SelectItem>
                      <SelectItem value="Mechanized">Mechanized</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="farmingMethod" className="text-base">Farming Method *</Label>
                  <Select value={formData.farmingMethod} onValueChange={(value: any) => handleChange('farmingMethod', value)} required>
                    <SelectTrigger className="h-12 text-base border-green-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Organic">Organic</SelectItem>
                      <SelectItem value="Inorganic">Inorganic</SelectItem>
                      <SelectItem value="Integrated">Integrated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 text-base bg-green-600 hover:bg-green-700"
                disabled={loading}
              >
                {loading ? 'Creating Account...' : 'Create Account'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}