import { createBrowserRouter } from 'react-router';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { DashboardLayout } from './components/DashboardLayout';
import { Home } from './pages/Home';
import { Logbook } from './pages/Logbook';
import { Library } from './pages/Library';
import { Tools } from './pages/Tools';
import { CropDetail } from './pages/CropDetail';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';

export const router = createBrowserRouter([
  {
    path: '/',
    element: (
      <AuthProvider>
        <Login />
      </AuthProvider>
    ),
  },
  {
    path: '/login',
    element: (
      <AuthProvider>
        <Login />
      </AuthProvider>
    ),
  },
  {
    path: '/signup',
    element: (
      <AuthProvider>
        <Signup />
      </AuthProvider>
    ),
  },
  {
    path: '/dashboard',
    element: (
      <AuthProvider>
        <ProtectedRoute>
          <DashboardLayout />
        </ProtectedRoute>
      </AuthProvider>
    ),
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: 'logbook',
        element: <Logbook />,
      },
      {
        path: 'library',
        element: <Library />,
      },
      {
        path: 'tools',
        element: <Tools />,
      },
      {
        path: 'crop/:id',
        element: <CropDetail />,
      },
    ],
  },
]);