// Nigerian crop data
import type { CropInfo } from '../types';

export const NIGERIAN_CROPS: CropInfo[] = [
  {
    name: 'Tomato',
    description: 'Tomato is a popular vegetable crop in Nigeria, grown for its fruits which are used in cooking and processing.',
    varieties: ['Roma VF', 'UC82', 'Ibadan Local', 'Rio Grande', 'Tropimech'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0. Rich in organic matter.',
    climateRequirements: 'Warm temperature (21-27°C), moderate rainfall, full sunlight.',
    farmingGuide: [
      'Prepare nursery beds and sow seeds 6-8 weeks before transplanting',
      'Transplant seedlings at 4-6 weeks old with 60cm x 60cm spacing',
      'Apply NPK fertilizer at 2, 4, and 6 weeks after transplanting',
      'Stake plants for support and prevent fruit rot',
      'Water regularly, especially during dry season',
      'Control pests and diseases promptly'
    ],
    commonPests: ['Fruit worm', 'Leaf miner', 'Whitefly', 'Bacterial wilt', 'Early blight'],
    controlMethods: [
      'Use resistant varieties',
      'Practice crop rotation',
      'Remove and destroy infected plants',
      'Apply appropriate pesticides when needed',
      'Maintain proper spacing for air circulation'
    ],
    maturityPeriodDays: 75
  },
  {
    name: 'Cassava',
    description: 'Cassava is a staple root crop in Nigeria, providing carbohydrates and used for various food products.',
    varieties: ['TMS 30572', 'TME 419', 'UMUCASS 36', 'UMUCASS 37', 'NR 8082'],
    soilRequirements: 'Well-drained sandy loam to loamy soil with pH 5.5-6.5.',
    climateRequirements: 'Warm tropical climate (25-29°C), 1000-1500mm annual rainfall.',
    farmingGuide: [
      'Select healthy stem cuttings 20-25cm long from mature plants',
      'Plant at 1m x 1m spacing, slanting or vertical placement',
      'Weed regularly, especially in first 3 months',
      'No fertilizer needed in fertile soil, but can apply NPK if needed',
      'Harvest at 10-12 months for optimal starch content'
    ],
    commonPests: ['Cassava mealybug', 'Green spider mite', 'Cassava mosaic disease', 'Bacterial blight'],
    controlMethods: [
      'Use disease-free planting materials',
      'Plant resistant varieties',
      'Remove and destroy infected plants',
      'Biological control using natural predators'
    ],
    maturityPeriodDays: 300
  },
  {
    name: 'Maize',
    description: 'Maize (corn) is a major cereal crop in Nigeria, used for food, feed, and industrial purposes.',
    varieties: ['SAMMAZ 50', 'SAMMAZ 51', 'Oba Super 7', 'Oba Super 9', 'ART/98/SW1-OB'],
    soilRequirements: 'Well-drained loamy soil with pH 5.5-7.5. Requires good fertility.',
    climateRequirements: 'Warm climate (25-30°C), 500-800mm rainfall during growing season.',
    farmingGuide: [
      'Prepare land by plowing and harrowing',
      'Plant seeds at 75cm x 25cm spacing, 2-3 seeds per hole',
      'Thin to one plant per stand after germination',
      'Apply NPK fertilizer at planting and 4 weeks after',
      'Weed at 3 and 6 weeks after planting',
      'Harvest when grains are hard and dry'
    ],
    commonPests: ['Stem borer', 'Armyworm', 'Stored grain weevil', 'Streak virus', 'Rust'],
    controlMethods: [
      'Early planting to avoid peak pest periods',
      'Use improved pest-resistant varieties',
      'Apply recommended pesticides',
      'Practice crop rotation',
      'Proper storage to prevent weevil damage'
    ],
    maturityPeriodDays: 90
  },
  {
    name: 'Cucumber',
    description: 'Cucumber is a popular vegetable crop grown for fresh consumption and salads.',
    varieties: ['Marketer', 'Ashley', 'Poinsett', 'Long Green', 'Market More'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0. Rich in organic matter.',
    climateRequirements: 'Warm temperature (18-24°C), moderate humidity.',
    farmingGuide: [
      'Prepare beds with organic manure',
      'Plant 2-3 seeds per hole at 1m x 0.5m spacing',
      'Thin to one plant per stand',
      'Apply NPK fertilizer at 2 and 4 weeks',
      'Provide support for climbing varieties',
      'Water regularly, avoid waterlogging'
    ],
    commonPests: ['Aphids', 'Fruit fly', 'Downy mildew', 'Powdery mildew'],
    controlMethods: [
      'Use resistant varieties',
      'Mulching to reduce soil splash',
      'Proper spacing for air circulation',
      'Apply appropriate fungicides and insecticides'
    ],
    maturityPeriodDays: 55
  },
  {
    name: 'Rice',
    description: 'Rice is an important staple cereal crop in Nigeria, grown in upland and lowland conditions.',
    varieties: ['FARO 44', 'FARO 52', 'FARO 60', 'NERICA 1', 'NERICA 2'],
    soilRequirements: 'Clay loam to clay soil with pH 5.5-6.5 for lowland; well-drained loamy soil for upland.',
    climateRequirements: 'Warm tropical climate (20-35°C), 1200-2000mm rainfall for rainfed system.',
    farmingGuide: [
      'Prepare land by plowing and puddling (for lowland)',
      'Transplant seedlings at 20cm x 20cm spacing or direct seed',
      'Maintain water level at 5-10cm for lowland rice',
      'Apply NPK fertilizer at transplanting, tillering, and panicle initiation',
      'Control weeds regularly',
      'Harvest when 80-85% of grains are golden yellow'
    ],
    commonPests: ['Rice blast', 'Stem borer', 'Gall midge', 'Bacterial leaf blight'],
    controlMethods: [
      'Use resistant varieties',
      'Proper water management',
      'Crop rotation',
      'Timely application of pesticides'
    ],
    maturityPeriodDays: 120
  },
  {
    name: 'Pepper',
    description: 'Pepper is a major vegetable crop in Nigeria, including bell pepper and hot pepper varieties.',
    varieties: ['Rodo NHV1-3', 'Tatase NHV1-4', 'Bell pepper California Wonder', 'Cayenne'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0. Rich in organic matter.',
    climateRequirements: 'Warm temperature (21-27°C), moderate rainfall.',
    farmingGuide: [
      'Raise seedlings in nursery for 6-8 weeks',
      'Transplant at 60cm x 60cm spacing',
      'Apply organic manure and NPK fertilizer',
      'Stake plants if necessary',
      'Water regularly during dry periods',
      'Harvest fruits at desired maturity'
    ],
    commonPests: ['Aphids', 'Fruit borer', 'Bacterial wilt', 'Anthracnose'],
    controlMethods: [
      'Use disease-free seedlings',
      'Crop rotation',
      'Proper drainage',
      'Apply appropriate pesticides'
    ],
    maturityPeriodDays: 70
  },
  {
    name: 'Yam',
    description: 'Yam is a staple tuber crop in Nigeria, highly valued for food security.',
    varieties: ['White yam (Dioscorea rotundata)', 'Water yam (D. alata)', 'Yellow yam (D. cayenensis)'],
    soilRequirements: 'Deep, well-drained loamy soil with pH 5.5-6.5.',
    climateRequirements: 'Warm humid climate (25-30°C), 1000-1500mm rainfall.',
    farmingGuide: [
      'Prepare mounds or ridges 1m apart',
      'Plant seed yams or setts at beginning of rainy season',
      'Stake plants for support',
      'Weed regularly, especially first 3 months',
      'Apply organic manure or NPK fertilizer',
      'Harvest when vines turn yellow and dry'
    ],
    commonPests: ['Yam beetle', 'Nematodes', 'Anthracnose', 'Virus diseases'],
    controlMethods: [
      'Use healthy planting materials',
      'Crop rotation',
      'Early staking',
      'Proper storage of harvested tubers'
    ],
    maturityPeriodDays: 240
  },
  {
    name: 'Okra',
    description: 'Okra is a popular vegetable crop grown for its edible green pods.',
    varieties: ['Clemson Spineless', 'Lady\'s Finger', 'NHAe-47-4', 'Pusa Sawani'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-6.8. Tolerates various soil types.',
    climateRequirements: 'Warm climate (21-30°C), requires adequate sunshine.',
    farmingGuide: [
      'Direct seed at 60cm x 30cm spacing',
      'Thin to one plant per stand after germination',
      'Apply NPK fertilizer at planting and 4 weeks after',
      'Weed regularly',
      'Water during dry periods',
      'Harvest pods when young and tender'
    ],
    commonPests: ['Pod borer', 'Aphids', 'Flea beetles', 'Leaf spot'],
    controlMethods: [
      'Early planting',
      'Crop rotation',
      'Regular harvesting to remove affected pods',
      'Apply appropriate pesticides'
    ],
    maturityPeriodDays: 60
  },
  {
    name: 'Beans (Cowpea)',
    description: 'Cowpea is an important legume crop in Nigeria, providing protein and improving soil fertility.',
    varieties: ['IT90K-277-2', 'Ife Brown', 'IAR-48', 'Sampea 7', 'Dan Borno'],
    soilRequirements: 'Well-drained sandy loam to clay loam with pH 6.0-7.5.',
    climateRequirements: 'Warm climate (25-35°C), 500-1200mm rainfall.',
    farmingGuide: [
      'Plant seeds at 60cm x 20cm spacing for erect varieties',
      'Plant 2-3 seeds per hole and thin to 1-2 plants',
      'Apply phosphorus fertilizer at planting',
      'Minimal nitrogen needed due to nitrogen fixation',
      'Weed at 3 and 6 weeks after planting',
      'Harvest pods when mature but before shattering'
    ],
    commonPests: ['Pod borer', 'Aphids', 'Flower thrips', 'Storage weevil'],
    controlMethods: [
      'Early planting',
      'Use improved resistant varieties',
      'Proper storage with improved storage bags',
      'Apply recommended pesticides when needed'
    ],
    maturityPeriodDays: 65
  },
  {
    name: 'Plantain',
    description: 'Plantain is a major starchy fruit crop in Nigeria, closely related to banana.',
    varieties: ['Agbagba', 'Apantu', 'Obino l\'Ewai', 'French plantain'],
    soilRequirements: 'Deep, fertile, well-drained loamy soil with pH 5.5-7.0.',
    climateRequirements: 'Humid tropical climate (25-30°C), 1500-2500mm rainfall, sheltered from strong winds.',
    farmingGuide: [
      'Prepare large planting holes',
      'Plant suckers at 3m x 3m spacing',
      'Mulch around plants',
      'Apply organic manure and NPK fertilizer regularly',
      'Desuckering to maintain desired plant population',
      'Prop fruiting plants to prevent falling'
    ],
    commonPests: ['Black sigatoka', 'Banana weevil', 'Nematodes'],
    controlMethods: [
      'Use healthy planting materials',
      'Regular removal of dead leaves',
      'Crop rotation',
      'Apply appropriate fungicides and pesticides'
    ],
    maturityPeriodDays: 300
  },
  {
    name: 'Watermelon',
    description: 'Watermelon is a popular fruit crop grown for its sweet, refreshing fruits.',
    varieties: ['Sugar Baby', 'Crimson Sweet', 'Charleston Gray'],
    soilRequirements: 'Well-drained sandy loam with pH 6.0-7.0.',
    climateRequirements: 'Warm climate (21-35°C), moderate rainfall.',
    farmingGuide: [
      'Prepare beds with organic manure',
      'Plant 3-4 seeds per hole at 2m x 2m spacing',
      'Thin to 2 plants per stand',
      'Apply NPK fertilizer at 2 and 4 weeks',
      'Provide adequate water, especially during fruiting',
      'Harvest when tendril near fruit dries'
    ],
    commonPests: ['Fruit fly', 'Aphids', 'Fusarium wilt', 'Anthracnose'],
    controlMethods: [
      'Crop rotation',
      'Use disease-free seeds',
      'Proper spacing',
      'Apply appropriate pesticides'
    ],
    maturityPeriodDays: 75
  },
  {
    name: 'Onion',
    description: 'Onion is an important vegetable crop grown for its edible bulbs.',
    varieties: ['Red Creole', 'Texas Grano', 'Bombay Red', 'White Creole'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0. Rich in organic matter.',
    climateRequirements: 'Cool climate (13-24°C) for bulb development, requires long days.',
    farmingGuide: [
      'Raise seedlings in nursery for 6-8 weeks',
      'Transplant at 15cm x 15cm spacing',
      'Apply NPK fertilizer at transplanting and 4 weeks after',
      'Water regularly, reduce watering near harvest',
      'Weed carefully to avoid damaging bulbs',
      'Harvest when tops fall over and dry'
    ],
    commonPests: ['Thrips', 'Purple blotch', 'Downy mildew', 'Bulb rot'],
    controlMethods: [
      'Crop rotation',
      'Use disease-free seedlings',
      'Proper drainage',
      'Apply appropriate fungicides'
    ],
    maturityPeriodDays: 120
  },
  {
    name: 'Sweet Potato',
    description: 'Sweet potato is a nutritious root crop grown for its edible tubers.',
    varieties: ['TIS 87/0087', 'Centennial', 'Ex-Igbariam', 'CIP Tanzania'],
    soilRequirements: 'Well-drained sandy loam to loamy soil with pH 5.5-6.5.',
    climateRequirements: 'Warm climate (24-27°C), 750-1000mm rainfall.',
    farmingGuide: [
      'Prepare ridges 1m apart',
      'Plant vine cuttings 30cm apart on ridges',
      'Weed at 3, 6, and 9 weeks after planting',
      'Minimal fertilizer needed in fertile soil',
      'Harvest at 4-5 months when leaves turn yellow'
    ],
    commonPests: ['Sweet potato weevil', 'Virus diseases', 'Root rot'],
    controlMethods: [
      'Use disease-free planting materials',
      'Crop rotation',
      'Early harvesting to avoid weevil damage',
      'Proper storage'
    ],
    maturityPeriodDays: 120
  },
  {
    name: 'Sorghum',
    description: 'Sorghum is a cereal crop that is drought-tolerant and important for food and feed.',
    varieties: ['ICSV 400', 'SK 5912', 'Samsorg 14', 'Samsorg 40'],
    soilRequirements: 'Wide soil adaptability, grows in pH 5.5-8.5. Prefers well-drained loamy soil.',
    climateRequirements: 'Warm climate (25-30°C), 400-600mm rainfall. Drought-tolerant.',
    farmingGuide: [
      'Prepare land by plowing',
      'Plant at 75cm x 30cm spacing',
      'Thin to 2 plants per stand',
      'Apply NPK fertilizer at planting and 4 weeks after',
      'Weed at 3 and 6 weeks',
      'Harvest when grains are hard'
    ],
    commonPests: ['Stem borer', 'Head bugs', 'Birds', 'Grain mold'],
    controlMethods: [
      'Use improved varieties',
      'Early planting',
      'Bird scaring during grain maturity',
      'Proper drying and storage'
    ],
    maturityPeriodDays: 100
  },
  {
    name: 'Groundnut',
    description: 'Groundnut (peanut) is an important oilseed and protein crop.',
    varieties: ['SAMNUT 10', 'SAMNUT 22', 'SAMNUT 23', 'Kampala'],
    soilRequirements: 'Well-drained sandy loam with pH 6.0-6.5. Requires calcium.',
    climateRequirements: 'Warm climate (25-30°C), 500-1000mm rainfall.',
    farmingGuide: [
      'Plant seeds at 50cm x 20cm spacing',
      'Plant 2 seeds per hole',
      'Apply phosphorus and potassium fertilizer',
      'Minimal nitrogen due to nitrogen fixation',
      'Earth up at flowering',
      'Harvest when leaves turn yellow'
    ],
    commonPests: ['Leaf spot', 'Rosette disease', 'Aphids', 'Storage pests'],
    controlMethods: [
      'Use disease-free seeds',
      'Crop rotation',
      'Early planting to avoid rosette',
      'Proper drying and storage'
    ],
    maturityPeriodDays: 100
  },
  {
    name: 'Cabbage',
    description: 'Cabbage is a leafy vegetable crop grown for its compact heads.',
    varieties: ['Gloria', 'Copenhagen Market', 'Tropical Pride', 'Oxylus'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.5. Rich in organic matter.',
    climateRequirements: 'Cool climate (15-20°C), requires adequate moisture.',
    farmingGuide: [
      'Raise seedlings in nursery for 4-6 weeks',
      'Transplant at 60cm x 45cm spacing',
      'Apply organic manure and NPK fertilizer',
      'Water regularly',
      'Control pests and diseases promptly',
      'Harvest when heads are firm and compact'
    ],
    commonPests: ['Diamondback moth', 'Aphids', 'Cabbage worm', 'Black rot'],
    controlMethods: [
      'Use resistant varieties',
      'Crop rotation',
      'Regular inspection and pest control',
      'Proper field hygiene'
    ],
    maturityPeriodDays: 75
  },
  {
    name: 'Carrot',
    description: 'Carrot is a root vegetable grown for its edible taproots.',
    varieties: ['Nantes', 'Chantenay', 'Imperator', 'Red Cored'],
    soilRequirements: 'Deep, loose, well-drained sandy loam with pH 6.0-6.8.',
    climateRequirements: 'Cool climate (16-21°C), requires consistent moisture.',
    farmingGuide: [
      'Prepare deep, fine seedbed',
      'Direct seed in rows 30cm apart',
      'Thin seedlings to 5cm spacing',
      'Apply balanced fertilizer',
      'Keep soil moist but not waterlogged',
      'Harvest when roots reach desired size'
    ],
    commonPests: ['Carrot fly', 'Aphids', 'Leaf blight', 'Root rot'],
    controlMethods: [
      'Crop rotation',
      'Proper soil preparation',
      'Regular weeding',
      'Apply appropriate pesticides if needed'
    ],
    maturityPeriodDays: 70
  },
  {
    name: 'Eggplant',
    description: 'Eggplant (Garden egg/African eggplant) is a popular vegetable in Nigerian cuisine.',
    varieties: ['Black Beauty', 'Ngwa Local', 'Long Purple', 'White Egg'],
    soilRequirements: 'Well-drained loamy soil with pH 5.5-6.8.',
    climateRequirements: 'Warm climate (21-27°C), requires full sunlight.',
    farmingGuide: [
      'Raise seedlings in nursery for 6-8 weeks',
      'Transplant at 75cm x 60cm spacing',
      'Apply organic manure and NPK fertilizer',
      'Stake plants if necessary',
      'Water regularly',
      'Harvest fruits when glossy and firm'
    ],
    commonPests: ['Fruit borer', 'Aphids', 'Whitefly', 'Bacterial wilt'],
    controlMethods: [
      'Use resistant varieties',
      'Crop rotation',
      'Regular scouting',
      'Apply appropriate pesticides'
    ],
    maturityPeriodDays: 80
  },
  {
    name: 'Melon (Egusi)',
    description: 'Egusi melon is grown primarily for its protein-rich seeds used in Nigerian soups.',
    varieties: ['Bara', 'Serewe', 'Agric Egusi'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0.',
    climateRequirements: 'Warm climate (25-35°C), moderate rainfall.',
    farmingGuide: [
      'Plant 2-3 seeds per hole at 2m x 2m spacing',
      'Thin to one plant per stand',
      'Can be intercropped with maize or yam',
      'Minimal fertilizer application',
      'Weed regularly',
      'Harvest when fruits turn yellow and dry'
    ],
    commonPests: ['Fruit fly', 'Aphids', 'Leaf beetles'],
    controlMethods: [
      'Crop rotation',
      'Early planting',
      'Manual removal of pests',
      'Apply pesticides if needed'
    ],
    maturityPeriodDays: 90
  },
  {
    name: 'Bitter Leaf',
    description: 'Bitter leaf is a traditional leafy vegetable used in Nigerian soups and herbal medicine.',
    varieties: ['Large leaf variety', 'Small leaf variety'],
    soilRequirements: 'Fertile, well-drained soil with pH 6.0-7.0.',
    climateRequirements: 'Warm humid climate, requires adequate moisture.',
    farmingGuide: [
      'Propagate from stem cuttings',
      'Plant at 1m x 1m spacing',
      'Apply organic manure',
      'Water regularly',
      'Begin harvesting leaves after 2-3 months',
      'Continuous harvesting possible'
    ],
    commonPests: ['Grasshoppers', 'Leaf beetles', 'Caterpillars'],
    controlMethods: [
      'Manual removal of pests',
      'Use organic pesticides',
      'Regular inspection'
    ],
    maturityPeriodDays: 60
  },
  {
    name: 'Pumpkin',
    description: 'Pumpkin is grown for its fruits and leaves, both used in Nigerian cooking.',
    varieties: ['Ugu (fluted pumpkin)', 'Round pumpkin'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0.',
    climateRequirements: 'Warm climate (20-30°C), moderate rainfall.',
    farmingGuide: [
      'Plant 2-3 seeds per hole at 2m x 2m spacing',
      'Thin to one plant per stand',
      'Apply organic manure and NPK fertilizer',
      'Provide support for climbing varieties',
      'Water regularly',
      'Harvest leaves continuously, fruits when mature'
    ],
    commonPests: ['Pumpkin beetle', 'Fruit fly', 'Powdery mildew'],
    controlMethods: [
      'Crop rotation',
      'Proper spacing',
      'Regular monitoring',
      'Apply appropriate pesticides'
    ],
    maturityPeriodDays: 70
  },
  {
    name: 'Spinach',
    description: 'Spinach is a leafy vegetable rich in vitamins and minerals.',
    varieties: ['Lagos Green', 'Bloomsdale', 'New Zealand Spinach'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0. Rich in nitrogen.',
    climateRequirements: 'Cool to warm climate (15-25°C).',
    farmingGuide: [
      'Direct seed in rows 30cm apart',
      'Thin to 10cm spacing',
      'Apply nitrogen-rich fertilizer',
      'Water regularly',
      'Begin harvesting in 4-6 weeks',
      'Continuous harvesting by cutting leaves'
    ],
    commonPests: ['Aphids', 'Leaf miners', 'Leaf spot'],
    controlMethods: [
      'Crop rotation',
      'Use disease-free seeds',
      'Proper spacing',
      'Apply appropriate pesticides'
    ],
    maturityPeriodDays: 45
  },
  {
    name: 'Garden Egg',
    description: 'Garden egg is a small variety of eggplant, popular in West African cuisine.',
    varieties: ['White garden egg', 'Green garden egg'],
    soilRequirements: 'Well-drained loamy soil with pH 5.5-6.8.',
    climateRequirements: 'Warm climate (21-27°C).',
    farmingGuide: [
      'Raise seedlings in nursery',
      'Transplant at 60cm x 60cm spacing',
      'Apply organic manure and NPK fertilizer',
      'Water regularly',
      'Harvest fruits when mature but before full ripening'
    ],
    commonPests: ['Fruit borer', 'Aphids', 'Bacterial wilt'],
    controlMethods: [
      'Use healthy seedlings',
      'Crop rotation',
      'Regular monitoring',
      'Apply pesticides when needed'
    ],
    maturityPeriodDays: 75
  },
  {
    name: 'Lettuce',
    description: 'Lettuce is a leafy vegetable commonly used in salads.',
    varieties: ['Great Lakes', 'Butterhead', 'Romaine', 'Ice Berg'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-7.0. Rich in organic matter.',
    climateRequirements: 'Cool climate (15-20°C).',
    farmingGuide: [
      'Raise seedlings or direct seed',
      'Transplant at 25cm x 25cm spacing',
      'Apply balanced fertilizer',
      'Water regularly, keep soil moist',
      'Harvest when heads are firm or leaves are large enough'
    ],
    commonPests: ['Aphids', 'Slugs', 'Leaf spot', 'Downy mildew'],
    controlMethods: [
      'Use disease-free seeds',
      'Proper spacing',
      'Good air circulation',
      'Apply appropriate controls'
    ],
    maturityPeriodDays: 50
  },
  {
    name: 'Ginger',
    description: 'Ginger is a spice crop grown for its aromatic rhizomes.',
    varieties: ['Local Nigerian ginger', 'Improved varieties'],
    soilRequirements: 'Well-drained loamy soil with pH 6.0-6.5. Rich in organic matter.',
    climateRequirements: 'Warm humid climate (20-30°C), 1500-3000mm rainfall.',
    farmingGuide: [
      'Select healthy rhizomes for planting',
      'Plant at 25cm x 25cm spacing on ridges',
      'Apply organic manure generously',
      'Mulch to conserve moisture',
      'Water regularly in dry season',
      'Harvest when leaves turn yellow (8-10 months)'
    ],
    commonPests: ['Rhizome rot', 'Shoot borer', 'Leaf spot'],
    controlMethods: [
      'Use disease-free planting materials',
      'Proper drainage',
      'Crop rotation',
      'Apply appropriate treatments'
    ],
    maturityPeriodDays: 240
  },
  {
    name: 'Jute Mallow',
    description: 'Jute mallow (Ewedu) is a traditional leafy vegetable in Nigerian cuisine.',
    varieties: ['Local varieties'],
    soilRequirements: 'Fertile, well-drained soil.',
    climateRequirements: 'Warm climate, adequate moisture.',
    farmingGuide: [
      'Direct seed in rows 30cm apart',
      'Thin to 15cm spacing',
      'Apply nitrogen fertilizer',
      'Water regularly',
      'Begin harvesting leaves after 3-4 weeks',
      'Continuous harvesting possible'
    ],
    commonPests: ['Leaf beetles', 'Grasshoppers'],
    controlMethods: [
      'Manual removal',
      'Use organic controls',
      'Regular inspection'
    ],
    maturityPeriodDays: 30
  },
  {
    name: 'African Yam Bean',
    description: 'African yam bean is a legume crop grown for its protein-rich seeds and tubers.',
    varieties: ['TSs series', 'Local varieties'],
    soilRequirements: 'Well-drained loamy soil with pH 5.5-6.5.',
    climateRequirements: 'Warm climate (25-30°C), 1000-1500mm rainfall.',
    farmingGuide: [
      'Plant at 1m x 0.5m spacing',
      'Provide support for climbing',
      'Minimal fertilizer needed',
      'Weed regularly',
      'Harvest seeds when pods dry',
      'Harvest tubers after seed harvest'
    ],
    commonPests: ['Pod borers', 'Aphids'],
    controlMethods: [
      'Crop rotation',
      'Use improved varieties',
      'Apply pesticides if needed'
    ],
    maturityPeriodDays: 150
  },
  {
    name: 'Cocoyam',
    description: 'Cocoyam is a root and tuber crop grown for its edible corms and leaves.',
    varieties: ['Ede ofe', 'Ede uhie', 'Xanthosoma'],
    soilRequirements: 'Moist, fertile, well-drained soil with pH 5.5-6.5.',
    climateRequirements: 'Humid tropical climate (20-30°C), high rainfall.',
    farmingGuide: [
      'Plant corms or cormels on ridges',
      'Space at 1m x 1m',
      'Apply organic manure',
      'Mulch to conserve moisture',
      'Weed regularly',
      'Harvest when leaves turn yellow'
    ],
    commonPests: ['Root rot', 'Nematodes', 'Corm rot'],
    controlMethods: [
      'Use healthy planting materials',
      'Proper drainage',
      'Crop rotation'
    ],
    maturityPeriodDays: 210
  },
  {
    name: 'Bambara Groundnut',
    description: 'Bambara groundnut is a drought-tolerant legume crop.',
    varieties: ['Cream colored', 'Brown', 'Black'],
    soilRequirements: 'Sandy to sandy loam soil with pH 5.0-6.5.',
    climateRequirements: 'Warm climate (25-30°C), 500-750mm rainfall. Drought-tolerant.',
    farmingGuide: [
      'Plant at 50cm x 20cm spacing',
      'Plant 2 seeds per hole',
      'Minimal fertilizer needed',
      'Weed early in crop cycle',
      'Harvest when pods mature'
    ],
    commonPests: ['Pod borers', 'Aphids', 'Storage pests'],
    controlMethods: [
      'Crop rotation',
      'Proper storage',
      'Use pesticides if needed'
    ],
    maturityPeriodDays: 110
  },
  {
    name: 'Sesame',
    description: 'Sesame is an oilseed crop valued for its nutritious seeds.',
    varieties: ['E8', 'Yandev-55', 'NCRI-Ben-01M'],
    soilRequirements: 'Well-drained loamy soil with pH 5.5-8.0.',
    climateRequirements: 'Warm climate (25-27°C), 500-650mm rainfall. Drought-tolerant.',
    farmingGuide: [
      'Direct seed in rows 50cm apart',
      'Thin to 10cm spacing',
      'Minimal fertilizer application',
      'Weed early',
      'Harvest when capsules turn brown',
      'Dry properly before storage'
    ],
    commonPests: ['Aphids', 'Capsule borer', 'Leaf spot'],
    controlMethods: [
      'Use disease-free seeds',
      'Crop rotation',
      'Apply pesticides if needed'
    ],
    maturityPeriodDays: 85
  },
  {
    name: 'Pigeon Pea',
    description: 'Pigeon pea is a perennial legume crop that improves soil fertility.',
    varieties: ['ICPL 87119', 'ICP 7035', 'Local varieties'],
    soilRequirements: 'Wide soil adaptability, pH 5.0-7.0. Drought-tolerant.',
    climateRequirements: 'Warm climate (20-35°C), 600-1000mm rainfall.',
    farmingGuide: [
      'Plant at 1m x 0.5m spacing',
      'Can be intercropped',
      'Minimal fertilizer needed',
      'Weed early in season',
      'Harvest pods when mature',
      'Can continue for multiple seasons'
    ],
    commonPests: ['Pod borers', 'Pod fly', 'Wilt'],
    controlMethods: [
      'Use resistant varieties',
      'Crop rotation',
      'Apply pesticides when needed'
    ],
    maturityPeriodDays: 140
  },
  {
    name: 'Kenaf',
    description: 'Kenaf is a fiber crop also grown for its leaves used as vegetable.',
    varieties: ['Everglades 41', 'Tainung 2', 'Local varieties'],
    soilRequirements: 'Well-drained loamy soil.',
    climateRequirements: 'Warm climate, adequate moisture.',
    farmingGuide: [
      'Direct seed in rows',
      'Thin to appropriate spacing',
      'Apply nitrogen fertilizer',
      'Water regularly for leaf production',
      'Harvest leaves continuously',
      'Harvest stems for fiber when mature'
    ],
    commonPests: ['Leaf beetles', 'Grasshoppers'],
    controlMethods: [
      'Regular monitoring',
      'Apply controls as needed'
    ],
    maturityPeriodDays: 120
  },
  {
    name: 'Amaranth',
    description: 'Amaranth is a nutritious leafy vegetable and grain crop.',
    varieties: ['Green amaranth', 'Red amaranth', 'Grain amaranth'],
    soilRequirements: 'Well-drained soil, wide adaptability.',
    climateRequirements: 'Warm climate (20-30°C).',
    farmingGuide: [
      'Direct seed in rows 30cm apart',
      'Thin seedlings as needed',
      'Apply nitrogen fertilizer',
      'Water regularly',
      'Begin harvesting leaves after 3-4 weeks',
      'Continuous harvesting for leaf types'
    ],
    commonPests: ['Aphids', 'Leaf miners', 'Caterpillars'],
    controlMethods: [
      'Crop rotation',
      'Manual removal',
      'Use appropriate controls'
    ],
    maturityPeriodDays: 40
  },
  {
    name: 'Fluted Pumpkin (Ugu)',
    description: 'Fluted pumpkin is highly valued for its nutritious leaves used in Nigerian soups.',
    varieties: ['Local varieties'],
    soilRequirements: 'Fertile, well-drained loamy soil.',
    climateRequirements: 'Warm humid climate, adequate moisture.',
    farmingGuide: [
      'Plant seeds or vine cuttings at 2m x 2m spacing',
      'Provide support for climbing',
      'Apply organic manure and NPK fertilizer',
      'Water regularly',
      'Begin harvesting leaves after 6-8 weeks',
      'Continuous harvesting possible'
    ],
    commonPests: ['Pumpkin beetle', 'Aphids', 'Leaf spot'],
    controlMethods: [
      'Regular inspection',
      'Manual removal of pests',
      'Apply pesticides if needed'
    ],
    maturityPeriodDays: 60
  }
];

export const getCropByName = (name: string): CropInfo | undefined => {
  return NIGERIAN_CROPS.find(crop => crop.name.toLowerCase() === name.toLowerCase());
};

export const searchCrops = (query: string): CropInfo[] => {
  const lowerQuery = query.toLowerCase();
  return NIGERIAN_CROPS.filter(crop => 
    crop.name.toLowerCase().includes(lowerQuery) ||
    crop.description.toLowerCase().includes(lowerQuery)
  );
};
