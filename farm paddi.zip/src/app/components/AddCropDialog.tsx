import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { AddNewCropForm } from './AddNewCropForm';
import { AddExistingCropForm } from './AddExistingCropForm';

interface AddCropDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function AddCropDialog({ open, onOpenChange, onSuccess }: AddCropDialogProps) {
  const [activeTab, setActiveTab] = useState('new');

  const handleSuccess = () => {
    onSuccess();
    onOpenChange(false);
    setActiveTab('new');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-green-800">Add Crop</DialogTitle>
        </DialogHeader>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="new">New Crop</TabsTrigger>
            <TabsTrigger value="existing">Existing Crop</TabsTrigger>
          </TabsList>
          <TabsContent value="new" className="mt-4">
            <AddNewCropForm onSuccess={handleSuccess} onCancel={() => onOpenChange(false)} />
          </TabsContent>
          <TabsContent value="existing" className="mt-4">
            <AddExistingCropForm onSuccess={handleSuccess} onCancel={() => onOpenChange(false)} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
