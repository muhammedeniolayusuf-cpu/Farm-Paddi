import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { auth, income as incomeApi, crops as cropsApi } from '../utils/supabase';
import { toast } from 'sonner';
import type { Income, Crop } from '../types';

interface AddIncomeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function AddIncomeDialog({ open, onOpenChange, onSuccess }: AddIncomeDialogProps) {
  const [crops, setCrops] = useState<Crop[]>([]);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    cropId: '',
    harvestQuantity: '',
    sellingPrice: '',
  });

  useEffect(() => {
    loadCrops();
  }, []);

  const loadCrops = async () => {
    try {
      const userCrops = await cropsApi.getAll();
      setCrops(userCrops);
    } catch (error) {
      console.error('Error loading crops:', error);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateTotal = (): number => {
    const price = parseFloat(formData.sellingPrice) || 0;
    // Try to extract numeric value from harvest quantity
    const quantityStr = formData.harvestQuantity.match(/[\d.]+/)?.[0] || '0';
    const quantity = parseFloat(quantityStr);
    return price * quantity;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.cropId || !formData.harvestQuantity || !formData.sellingPrice) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      const profile = await auth.getProfile();
      if (!profile) return;

      const income: Income = {
        id: Date.now().toString(),
        userId: profile.id,
        cropId: formData.cropId,
        date: formData.date,
        harvestQuantity: formData.harvestQuantity,
        sellingPrice: parseFloat(formData.sellingPrice),
        totalRevenue: calculateTotal(),
      };

      await incomeApi.save(income);
      toast.success('Income recorded successfully!');
      
      // Reset form
      setFormData({
        date: new Date().toISOString().split('T')[0],
        cropId: '',
        harvestQuantity: '',
        sellingPrice: '',
      });
      
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error saving income:', error);
      toast.error(error.message || 'Failed to save income');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl text-green-800">Add Income</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Date *</Label>
            <Input
              type="date"
              value={formData.date}
              onChange={(e) => handleChange('date', e.target.value)}
              max={new Date().toISOString().split('T')[0]}
              required
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Crop *</Label>
            <Select value={formData.cropId} onValueChange={(value) => handleChange('cropId', value)} required>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Select crop" />
              </SelectTrigger>
              <SelectContent>
                {crops.map((crop) => (
                  <SelectItem key={crop.id} value={crop.id}>
                    {crop.cropName} - {crop.variety}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Harvest Quantity *</Label>
            <Input
              placeholder="e.g., 50 kg, 100 bags, 200 bunches"
              value={formData.harvestQuantity}
              onChange={(e) => handleChange('harvestQuantity', e.target.value)}
              required
              className="h-12"
            />
          </div>

          <div className="space-y-2">
            <Label>Selling Price per Unit (₦) *</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="Enter price per unit"
              value={formData.sellingPrice}
              onChange={(e) => handleChange('sellingPrice', e.target.value)}
              required
              className="h-12"
            />
          </div>

          {formData.harvestQuantity && formData.sellingPrice && (
            <div className="p-4 bg-green-50 border border-green-300 rounded-lg">
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-green-700">₦{calculateTotal().toLocaleString()}</p>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              Save Income
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}