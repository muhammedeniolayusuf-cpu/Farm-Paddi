import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { auth, crops as cropsApi } from '../utils/supabase';
import { NIGERIAN_CROPS, getCropByName } from '../data/crops';
import { toast } from 'sonner';
import type { Crop } from '../types';

interface AddExistingCropFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const ACTIVITY_TYPES = ['Planting', 'Weeding', 'Fertilizer Application', 'Pest Control', 'Irrigation'];

export function AddExistingCropForm({ onSuccess, onCancel }: AddExistingCropFormProps) {
  const [formData, setFormData] = useState({
    cropName: '',
    variety: '',
    ageInWeeks: '',
    previousActivities: [] as string[],
  });

  const selectedCropInfo = formData.cropName ? getCropByName(formData.cropName) : null;

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleActivity = (activity: string) => {
    setFormData(prev => ({
      ...prev,
      previousActivities: prev.previousActivities.includes(activity)
        ? prev.previousActivities.filter(a => a !== activity)
        : [...prev.previousActivities, activity],
    }));
  };

  const handleSubmit = async () => {
    if (!formData.cropName || !formData.variety || !formData.ageInWeeks) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      const profile = await auth.getProfile();
      if (!profile || !selectedCropInfo) return;

      const ageInDays = parseInt(formData.ageInWeeks) * 7;
      const remainingDays = selectedCropInfo.maturityPeriodDays - ageInDays;
      
      const plantDate = new Date();
      plantDate.setDate(plantDate.getDate() - ageInDays);
      
      const expectedHarvestDate = new Date();
      expectedHarvestDate.setDate(expectedHarvestDate.getDate() + remainingDays);

      // Determine current stage based on age
      let currentStage = 'Germination';
      const agePercent = (ageInDays / selectedCropInfo.maturityPeriodDays) * 100;
      if (agePercent > 80) currentStage = 'Maturity';
      else if (agePercent > 60) currentStage = 'Fruiting';
      else if (agePercent > 40) currentStage = 'Flowering';
      else if (agePercent > 20) currentStage = 'Vegetative';

      const crop: Crop = {
        id: Date.now().toString(),
        userId: profile.id,
        cropName: formData.cropName,
        variety: formData.variety,
        datePlanted: plantDate.toISOString().split('T')[0],
        currentStage,
        daysToHarvest: remainingDays > 0 ? remainingDays : 0,
        soilType: 'Unknown',
        farmSize: 'Not specified',
        plantingMethod: 'Not specified',
        irrigationType: 'Not specified',
        farmingType: profile.farmingType,
        farmingMethod: profile.farmingMethod,
        expectedHarvestDate: expectedHarvestDate.toISOString().split('T')[0],
        isActive: remainingDays > 0,
        recommendations: {
          spacing: selectedCropInfo.soilRequirements,
          maturityPeriod: `${selectedCropInfo.maturityPeriodDays} days total, ${remainingDays} days remaining`,
          fertilizerPlan: 'Continue with regular fertilizer schedule',
          harvestWindow: `Expected harvest around ${expectedHarvestDate.toLocaleDateString('en-NG')}`,
          keyPractices: selectedCropInfo.farmingGuide.slice(0, 5),
        },
      };

      await cropsApi.save(crop);
      toast.success('Existing crop added successfully!');
      onSuccess();
    } catch (error: any) {
      console.error('Error saving existing crop:', error);
      toast.error(error.message || 'Failed to save crop');
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Select Crop *</Label>
          <Select value={formData.cropName} onValueChange={(value) => handleChange('cropName', value)}>
            <SelectTrigger className="h-12">
              <SelectValue placeholder="Choose crop type" />
            </SelectTrigger>
            <SelectContent>
              {NIGERIAN_CROPS.map((crop) => (
                <SelectItem key={crop.name} value={crop.name}>{crop.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {formData.cropName && selectedCropInfo && (
          <div className="space-y-2">
            <Label>Select Variety *</Label>
            <Select value={formData.variety} onValueChange={(value) => handleChange('variety', value)}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Choose variety" />
              </SelectTrigger>
              <SelectContent>
                {selectedCropInfo.varieties.map((variety) => (
                  <SelectItem key={variety} value={variety}>{variety}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="space-y-2">
          <Label>Current Age in Weeks *</Label>
          <Input
            type="number"
            min="1"
            placeholder="e.g., 4"
            value={formData.ageInWeeks}
            onChange={(e) => handleChange('ageInWeeks', e.target.value)}
            className="h-12"
          />
          {formData.ageInWeeks && selectedCropInfo && (
            <p className="text-sm text-gray-600">
              {Math.floor(parseInt(formData.ageInWeeks) * 7)} days old. 
              Approximate maturity: {selectedCropInfo.maturityPeriodDays} days total.
            </p>
          )}
        </div>

        <div className="space-y-3">
          <Label>Previous Activities (Optional)</Label>
          <p className="text-sm text-gray-600">Select activities you've already completed</p>
          <Card className="border-green-200">
            <CardContent className="p-4 space-y-3">
              {ACTIVITY_TYPES.map((activity) => (
                <div key={activity} className="flex items-center space-x-2">
                  <Checkbox
                    id={activity}
                    checked={formData.previousActivities.includes(activity)}
                    onCheckedChange={() => toggleActivity(activity)}
                  />
                  <label
                    htmlFor={activity}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {activity}
                  </label>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {formData.cropName && formData.ageInWeeks && selectedCropInfo && (
          <Card className="border-2 border-blue-600 bg-blue-50">
            <CardContent className="p-4">
              <h4 className="font-semibold text-blue-800 mb-2">Adjusted Timeline</h4>
              <div className="space-y-2 text-sm">
                <p>
                  <span className="font-medium">Estimated planting date:</span>{' '}
                  {new Date(Date.now() - parseInt(formData.ageInWeeks) * 7 * 24 * 60 * 60 * 1000).toLocaleDateString('en-NG')}
                </p>
                <p>
                  <span className="font-medium">Days remaining to harvest:</span>{' '}
                  {Math.max(0, selectedCropInfo.maturityPeriodDays - (parseInt(formData.ageInWeeks) * 7))} days
                </p>
                <p>
                  <span className="font-medium">Expected harvest:</span>{' '}
                  {new Date(Date.now() + Math.max(0, (selectedCropInfo.maturityPeriodDays - parseInt(formData.ageInWeeks) * 7)) * 24 * 60 * 60 * 1000).toLocaleDateString('en-NG')}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onCancel} className="border-gray-300">
          Cancel
        </Button>
        <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
          Add Crop
        </Button>
      </div>
    </div>
  );
}