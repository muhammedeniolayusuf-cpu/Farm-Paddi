import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client for auth and admin operations
const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// Enable logger
app.use("*", logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-240f57ee/health", (c) => {
  return c.json({ status: "ok" });
});

// ===== AUTH ROUTES =====

// Sign up endpoint
app.post("/make-server-240f57ee/signup", async (c) => {
  try {
    const body = await c.req.json();
    const {
      email,
      phone,
      password,
      fullName,
      farmLocation,
      farmSize,
      farmingType,
      farmingMethod,
    } = body;

    // Create user with Supabase Auth
    const { data, error } =
      await supabase.auth.admin.createUser({
        email: email || `${phone}@farmpaddi.app`,
        password: password,
        user_metadata: {
          fullName,
          phone,
          email,
          farmLocation,
          farmSize,
          farmingType,
          farmingMethod,
        },
        // Automatically confirm the user's email since an email server hasn't been configured.
        email_confirm: true,
      });

    if (error) {
      console.log("Signup error:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({
      user: {
        id: data.user.id,
        email: data.user.email,
        ...data.user.user_metadata,
      },
    });
  } catch (error) {
    console.log("Signup exception:", error);
    return c.json({ error: "Failed to create user" }, 500);
  }
});

// Get user profile
app.get("/make-server-240f57ee/user/profile", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    return c.json({
      user: {
        id: user.id,
        email: user.email,
        ...user.user_metadata,
      },
    });
  } catch (error) {
    console.log("Get profile error:", error);
    return c.json({ error: "Failed to get profile" }, 500);
  }
});

// ===== CROP ROUTES =====

// Get all crops for a user
app.get("/make-server-240f57ee/crops", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const crops = await kv.getByPrefix(`crop:${user.id}:`);
    return c.json({ crops });
  } catch (error) {
    console.log("Get crops error:", error);
    return c.json({ error: "Failed to get crops" }, 500);
  }
});

// Create or update a crop
app.post("/make-server-240f57ee/crops", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const crop = await c.req.json();
    const key = `crop:${user.id}:${crop.id}`;
    await kv.set(key, crop);

    return c.json({ crop });
  } catch (error) {
    console.log("Save crop error:", error);
    return c.json({ error: "Failed to save crop" }, 500);
  }
});

// Delete a crop
app.delete("/make-server-240f57ee/crops/:id", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const cropId = c.req.param("id");
    const key = `crop:${user.id}:${cropId}`;
    await kv.del(key);

    return c.json({ success: true });
  } catch (error) {
    console.log("Delete crop error:", error);
    return c.json({ error: "Failed to delete crop" }, 500);
  }
});

// ===== ACTIVITY ROUTES =====

// Get all activities for a user (optionally filtered by crop)
app.get("/make-server-240f57ee/activities", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const cropId = c.req.query("cropId");
    const prefix = cropId
      ? `activity:${user.id}:${cropId}:`
      : `activity:${user.id}:`;
    const activities = await kv.getByPrefix(prefix);

    return c.json({ activities });
  } catch (error) {
    console.log("Get activities error:", error);
    return c.json({ error: "Failed to get activities" }, 500);
  }
});

// Create or update an activity
app.post("/make-server-240f57ee/activities", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const activity = await c.req.json();
    const key = `activity:${user.id}:${activity.cropId}:${activity.id}`;
    await kv.set(key, activity);

    return c.json({ activity });
  } catch (error) {
    console.log("Save activity error:", error);
    return c.json({ error: "Failed to save activity" }, 500);
  }
});

// ===== EXPENSE ROUTES =====

// Get all expenses for a user (optionally filtered by crop)
app.get("/make-server-240f57ee/expenses", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const cropId = c.req.query("cropId");
    let expenses = await kv.getByPrefix(`expense:${user.id}:`);

    // Filter by cropId if provided
    if (cropId) {
      expenses = expenses.filter(
        (e: any) => e.cropId === cropId,
      );
    }

    return c.json({ expenses });
  } catch (error) {
    console.log("Get expenses error:", error);
    return c.json({ error: "Failed to get expenses" }, 500);
  }
});

// Create or update an expense
app.post("/make-server-240f57ee/expenses", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const expense = await c.req.json();
    const key = `expense:${user.id}:${expense.id}`;
    await kv.set(key, expense);

    return c.json({ expense });
  } catch (error) {
    console.log("Save expense error:", error);
    return c.json({ error: "Failed to save expense" }, 500);
  }
});

// ===== INCOME ROUTES =====

// Get all income for a user (optionally filtered by crop)
app.get("/make-server-240f57ee/income", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const cropId = c.req.query("cropId");
    let income = await kv.getByPrefix(`income:${user.id}:`);

    // Filter by cropId if provided
    if (cropId) {
      income = income.filter((i: any) => i.cropId === cropId);
    }

    return c.json({ income });
  } catch (error) {
    console.log("Get income error:", error);
    return c.json({ error: "Failed to get income" }, 500);
  }
});

// Create or update income
app.post("/make-server-240f57ee/income", async (c) => {
  try {
    const accessToken = c.req
      .header("Authorization")
      ?.split(" ")[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const income = await c.req.json();
    const key = `income:${user.id}:${income.id}`;
    await kv.set(key, income);

    return c.json({ income });
  } catch (error) {
    console.log("Save income error:", error);
    return c.json({ error: "Failed to save income" }, 500);
  }
});

Deno.serve(app.fetch);