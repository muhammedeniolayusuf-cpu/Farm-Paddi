import { useState, useEffect } from 'react';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Plus, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { expenses as expensesApi, income as incomeApi, activities as activitiesApi } from '../utils/supabase';
import type { Expense, Income, Activity } from '../types';
import { AddExpenseDialog } from '../components/AddExpenseDialog';
import { AddIncomeDialog } from '../components/AddIncomeDialog';

export function Logbook() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [income, setIncome] = useState<Income[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [showAddIncome, setShowAddIncome] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [expensesData, incomeData, activitiesData] = await Promise.all([
        expensesApi.getAll(),
        incomeApi.getAll(),
        activitiesApi.getAll(),
      ]);
      setExpenses(expensesData);
      setIncome(incomeData);
      setActivities(activitiesData);
    } catch (error) {
      console.error('Error loading logbook data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const totalIncome = income.reduce((sum, inc) => sum + inc.totalRevenue, 0);
  const profit = totalIncome - totalExpenses;

  const handleRefresh = () => {
    loadData();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-green-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-6">
        <h1 className="text-2xl font-semibold">Logbook</h1>
        <p className="text-sm opacity-90 mt-1">Track your farm finances and activities</p>
      </div>

      {/* Profit Summary */}
      <div className="px-4 py-6">
        <Card className="border-2 border-green-600 bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold text-green-800 mb-4">Profit Summary</h2>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <TrendingUp className="w-6 h-6 text-green-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Income</p>
                <p className="text-xl font-bold text-green-700">₦{totalIncome.toLocaleString()}</p>
              </div>
              <div className="text-center">
                <TrendingDown className="w-6 h-6 text-red-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Expenses</p>
                <p className="text-xl font-bold text-red-700">₦{totalExpenses.toLocaleString()}</p>
              </div>
              <div className="text-center">
                <DollarSign className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Profit</p>
                <p className={`text-xl font-bold ${profit >= 0 ? 'text-blue-700' : 'text-red-700'}`}>
                  ₦{profit.toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <div className="px-4 pb-6">
        <Tabs defaultValue="expenses" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="expenses">Expenses</TabsTrigger>
            <TabsTrigger value="income">Income</TabsTrigger>
            <TabsTrigger value="activities">Activities</TabsTrigger>
          </TabsList>

          {/* Expenses Tab */}
          <TabsContent value="expenses" className="space-y-4 mt-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-green-800">Expense Records</h3>
              <Button
                onClick={() => setShowAddExpense(true)}
                size="sm"
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add
              </Button>
            </div>

            {expenses.length === 0 ? (
              <Card className="border-dashed border-2 border-gray-300">
                <CardContent className="p-8 text-center">
                  <p className="text-gray-600 mb-4">No expenses recorded yet</p>
                  <Button onClick={() => setShowAddExpense(true)} variant="outline">
                    Record First Expense
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {expenses
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((expense) => (
                    <Card key={expense.id} className="border-red-200">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-semibold text-gray-800">{expense.description}</p>
                            <p className="text-sm text-gray-600 mt-1">
                              {expense.category} • {new Date(expense.date).toLocaleDateString('en-NG')}
                            </p>
                          </div>
                          <p className="text-lg font-bold text-red-700">₦{expense.amount.toLocaleString()}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </TabsContent>

          {/* Income Tab */}
          <TabsContent value="income" className="space-y-4 mt-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-green-800">Income Records</h3>
              <Button
                onClick={() => setShowAddIncome(true)}
                size="sm"
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add
              </Button>
            </div>

            {income.length === 0 ? (
              <Card className="border-dashed border-2 border-gray-300">
                <CardContent className="p-8 text-center">
                  <p className="text-gray-600 mb-4">No income recorded yet</p>
                  <Button onClick={() => setShowAddIncome(true)} variant="outline">
                    Record First Income
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {income
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((inc) => (
                    <Card key={inc.id} className="border-green-200">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-semibold text-gray-800">Harvest Sale</p>
                            <p className="text-sm text-gray-600 mt-1">
                              {inc.harvestQuantity} • {new Date(inc.date).toLocaleDateString('en-NG')}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              Price: ₦{inc.sellingPrice.toLocaleString()} per unit
                            </p>
                          </div>
                          <p className="text-lg font-bold text-green-700">₦{inc.totalRevenue.toLocaleString()}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </TabsContent>

          {/* Activities Tab */}
          <TabsContent value="activities" className="space-y-4 mt-4">
            <h3 className="text-lg font-semibold text-green-800">Activity History</h3>

            {activities.length === 0 ? (
              <Card className="border-dashed border-2 border-gray-300">
                <CardContent className="p-8 text-center">
                  <p className="text-gray-600">No activities logged yet</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {activities
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((activity) => (
                    <Card key={activity.id} className="border-gray-200">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <p className="font-semibold text-gray-800">{activity.activityType}</p>
                            <p className="text-sm text-gray-600 mt-1">
                              {new Date(activity.date).toLocaleDateString('en-NG')}
                            </p>
                            {activity.quantityUsed && (
                              <p className="text-xs text-gray-500 mt-1">Quantity: {activity.quantityUsed}</p>
                            )}
                            {activity.notes && (
                              <p className="text-xs text-gray-500 mt-1">{activity.notes}</p>
                            )}
                          </div>
                          {activity.cost && (
                            <p className="text-sm font-medium text-green-700">₦{activity.cost.toLocaleString()}</p>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <AddExpenseDialog
        open={showAddExpense}
        onOpenChange={setShowAddExpense}
        onSuccess={handleRefresh}
      />

      <AddIncomeDialog
        open={showAddIncome}
        onOpenChange={setShowAddIncome}
        onSuccess={handleRefresh}
      />
    </div>
  );
}