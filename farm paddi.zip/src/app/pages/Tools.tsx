import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Calculator, Camera, CloudSun, Info } from 'lucide-react';
import { NIGERIAN_CROPS } from '../data/crops';

export function Tools() {
  const [seedCalcData, setSeedCalcData] = useState({
    farmSize: '',
    crop: '',
    spacing: '',
  });
  const [seedResult, setSeedResult] = useState<string | null>(null);

  const handleSeedCalcChange = (field: string, value: string) => {
    setSeedCalcData(prev => ({ ...prev, [field]: value }));
  };

  const calculateSeeds = () => {
    if (!seedCalcData.farmSize || !seedCalcData.crop || !seedCalcData.spacing) {
      return;
    }

    // Simple seed calculation (this is a basic example)
    const farmSizeNum = parseFloat(seedCalcData.farmSize);
    const spacingNum = parseFloat(seedCalcData.spacing);
    
    if (isNaN(farmSizeNum) || isNaN(spacingNum) || spacingNum === 0) {
      setSeedResult('Please enter valid numbers');
      return;
    }

    // Calculate based on 10,000 sq meters per hectare
    const sqMeters = farmSizeNum * 10000;
    const spacingSqMeters = (spacingNum / 100) * (spacingNum / 100); // Convert cm to meters
    const plantsNeeded = Math.ceil(sqMeters / spacingSqMeters);
    
    // Estimate seeds (assuming 10% extra for germination failure)
    const seedsNeeded = Math.ceil(plantsNeeded * 1.1);

    setSeedResult(`You will need approximately ${seedsNeeded.toLocaleString()} seeds for ${farmSizeNum} hectares with ${spacingNum}cm spacing.`);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-6">
        <h1 className="text-2xl font-semibold">Tools</h1>
        <p className="text-sm opacity-90 mt-1">Farming calculators and utilities</p>
      </div>

      <div className="px-4 py-6 space-y-4">
        {/* Seed Calculator */}
        <Card className="border-2 border-green-600">
          <CardHeader className="bg-green-50">
            <div className="flex items-center gap-3">
              <div className="bg-green-600 p-2 rounded-lg">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-green-800">Seed Calculator</CardTitle>
                <p className="text-sm text-gray-600 mt-1">Calculate seed requirements</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4 space-y-4">
            <div className="space-y-2">
              <Label>Farm Size (hectares)</Label>
              <Input
                type="number"
                placeholder="e.g., 2.5"
                value={seedCalcData.farmSize}
                onChange={(e) => handleSeedCalcChange('farmSize', e.target.value)}
                className="h-12"
              />
            </div>

            <div className="space-y-2">
              <Label>Crop</Label>
              <Select value={seedCalcData.crop} onValueChange={(value) => handleSeedCalcChange('crop', value)}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select crop" />
                </SelectTrigger>
                <SelectContent>
                  {NIGERIAN_CROPS.map((crop) => (
                    <SelectItem key={crop.name} value={crop.name}>{crop.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Spacing (cm)</Label>
              <Input
                type="number"
                placeholder="e.g., 50"
                value={seedCalcData.spacing}
                onChange={(e) => handleSeedCalcChange('spacing', e.target.value)}
                className="h-12"
              />
            </div>

            <Button 
              onClick={calculateSeeds}
              className="w-full h-12 bg-green-600 hover:bg-green-700"
            >
              Calculate Seeds
            </Button>

            {seedResult && (
              <Card className="border-blue-600 bg-blue-50">
                <CardContent className="p-4">
                  <p className="text-sm text-blue-900">{seedResult}</p>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* Pest Identifier - Coming Soon */}
        <Card className="border-2 border-gray-300 opacity-75">
          <CardHeader className="bg-gray-50">
            <div className="flex items-center gap-3">
              <div className="bg-gray-400 p-2 rounded-lg">
                <Camera className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-gray-700">Pest Identifier</CardTitle>
                <p className="text-sm text-gray-500 mt-1">Coming Soon - AI-powered pest detection</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="text-center py-8">
              <Info className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600 text-sm">
                This feature will allow you to upload images of pests or diseases and get instant identification and treatment recommendations.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Weather Integration - Coming Soon */}
        <Card className="border-2 border-gray-300 opacity-75">
          <CardHeader className="bg-gray-50">
            <div className="flex items-center gap-3">
              <div className="bg-gray-400 p-2 rounded-lg">
                <CloudSun className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-gray-700">Weather Forecast</CardTitle>
                <p className="text-sm text-gray-500 mt-1">Coming Soon - Local weather data</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="text-center py-8">
              <Info className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600 text-sm">
                Get location-specific weather forecasts to plan your farming activities better.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}