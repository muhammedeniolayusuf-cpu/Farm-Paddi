import { Home, BookOpen, Library, Wrench } from 'lucide-react';
import { Link, useLocation } from 'react-router';

const navItems = [
  { path: '/dashboard', icon: Home, label: 'Home' },
  { path: '/dashboard/logbook', icon: BookOpen, label: 'Logbook' },
  { path: '/dashboard/library', icon: Library, label: 'Library' },
  { path: '/dashboard/tools', icon: Wrench, label: 'Tools' },
];

export function BottomNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-green-600 shadow-lg z-50">
      <div className="flex justify-around items-center h-20 max-w-screen-xl mx-auto">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
                isActive 
                  ? 'text-green-600 bg-green-50' 
                  : 'text-gray-600 hover:text-green-600 hover:bg-green-50'
              }`}
            >
              <Icon className={`w-6 h-6 mb-1 ${isActive ? 'stroke-[2.5]' : ''}`} />
              <span className={`text-xs ${isActive ? 'font-semibold' : ''}`}>{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
