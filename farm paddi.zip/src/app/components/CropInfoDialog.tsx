import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Card, CardContent } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import type { CropInfo } from '../types';
import { Calendar, Droplet, ThermometerSun, Bug, Shield } from 'lucide-react';

interface CropInfoDialogProps {
  crop: CropInfo | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CropInfoDialog({ crop, open, onOpenChange }: CropInfoDialogProps) {
  if (!crop) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-green-800">{crop.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Description */}
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <p className="text-sm text-gray-700">{crop.description}</p>
            </CardContent>
          </Card>

          {/* Quick Info */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <h4 className="font-semibold text-blue-800">Maturity</h4>
                </div>
                <p className="text-2xl font-bold text-blue-700">{crop.maturityPeriodDays} days</p>
              </CardContent>
            </Card>
            <Card className="border-green-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <ThermometerSun className="w-5 h-5 text-green-600" />
                  <h4 className="font-semibold text-green-800">Varieties</h4>
                </div>
                <p className="text-2xl font-bold text-green-700">{crop.varieties.length}</p>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="varieties" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="varieties">Varieties</TabsTrigger>
              <TabsTrigger value="requirements">Requirements</TabsTrigger>
              <TabsTrigger value="guide">Guide</TabsTrigger>
              <TabsTrigger value="pests">Pests</TabsTrigger>
            </TabsList>

            {/* Varieties */}
            <TabsContent value="varieties" className="space-y-3 mt-4">
              <h3 className="font-semibold text-green-800">Common Varieties</h3>
              <div className="grid grid-cols-1 gap-2">
                {crop.varieties.map((variety, idx) => (
                  <Card key={idx} className="border-gray-200">
                    <CardContent className="p-3">
                      <p className="text-sm font-medium text-gray-800">{variety}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Requirements */}
            <TabsContent value="requirements" className="space-y-4 mt-4">
              <Card className="border-brown-200 bg-amber-50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Droplet className="w-5 h-5 text-brown-600" />
                    <h4 className="font-semibold text-brown-800">Soil Requirements</h4>
                  </div>
                  <p className="text-sm text-gray-700">{crop.soilRequirements}</p>
                </CardContent>
              </Card>
              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <ThermometerSun className="w-5 h-5 text-orange-600" />
                    <h4 className="font-semibold text-orange-800">Climate Requirements</h4>
                  </div>
                  <p className="text-sm text-gray-700">{crop.climateRequirements}</p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Farming Guide */}
            <TabsContent value="guide" className="space-y-3 mt-4">
              <h3 className="font-semibold text-green-800">Step by Step Farming Guide</h3>
              <div className="space-y-3">
                {crop.farmingGuide.map((step, idx) => (
                  <Card key={idx} className="border-green-200">
                    <CardContent className="p-4">
                      <div className="flex gap-3">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center font-semibold text-sm">
                          {idx + 1}
                        </div>
                        <p className="text-sm text-gray-700 flex-1 pt-1">{step}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Pests & Diseases */}
            <TabsContent value="pests" className="space-y-4 mt-4">
              <Card className="border-red-200 bg-red-50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Bug className="w-5 h-5 text-red-600" />
                    <h4 className="font-semibold text-red-800">Common Pests & Diseases</h4>
                  </div>
                  <ul className="list-disc list-inside space-y-1">
                    {crop.commonPests.map((pest, idx) => (
                      <li key={idx} className="text-sm text-gray-700">{pest}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Shield className="w-5 h-5 text-blue-600" />
                    <h4 className="font-semibold text-blue-800">Control Methods</h4>
                  </div>
                  <ul className="list-disc list-inside space-y-1">
                    {crop.controlMethods.map((method, idx) => (
                      <li key={idx} className="text-sm text-gray-700">{method}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}
