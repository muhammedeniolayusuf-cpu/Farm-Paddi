
  # farm paddi

  This is a code bundle for farm paddi. The original project is available at https://www.figma.com/design/y9wTDodP63pRlLjQ8SiuwM/farm-paddi.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  