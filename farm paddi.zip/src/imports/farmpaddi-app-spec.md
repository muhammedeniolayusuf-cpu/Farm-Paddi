RODUCT NAME
FarmPaddi

PRODUCT TYPE
Mobile application (Android first)

TARGET USERS
Smallholder farmers in Nigeria
Farm cooperatives
Student farmers
Rural farmers with low digital literacy

DESIGN STYLE
Simple
Clean
Agriculture themed
Modern but not flashy
Green dominant color palette
Offline-first mindset
Large buttons and readable fonts
Low cognitive load

PRIMARY GOAL OF THE APP
Help farmers plan, manage, and track their crops using research-based guidance and simple farm record keeping tools.

CORE NAVIGATION STRUCTURE

Bottom navigation bar with 4 tabs:

Home

Logbook

Library

Tools

No marketplace for now. No notifications for now.

AUTHENTICATION FLOW

Login Screen

Input: Phone number or Email

Password

Login button

Link to Create Account

Create Account Screen

Full Name

Phone number or Email

Password

Confirm password

Farm location (State, Local Government)

Farm size

Farming type (Manual or Mechanized)

Farming method (Organic, Inorganic, Integrated)

Create Account button

No OTP. No guest mode.

HOME DASHBOARD

Purpose: Overview of all farm activities.

Sections:

A. Farm Summary Card

Total crops added

Active crops

Upcoming tasks

B. My Crops Section
Displayed as clickable cards.
Each crop card shows:

Crop name

Variety

Date planted

Current stage

Days to harvest

When clicked, it opens Crop Detail Page.

C. Add Crop Button (Floating Action Button)

When clicked, it shows two options:

Add New Crop

Add Existing Crop

ADD NEW CROP FLOW

Step 1: Select Crop
Display list of 32 most common food and vegetable crops in Nigeria.

Step 2: Select Variety
Show common varieties for selected crop.

Step 3: Farm Information

Soil type

Farm size

Planting method (Broadcast, Transplant, Drilling, etc.)

Irrigation type

Manual or Mechanized

Organic, Inorganic, Integrated

Step 4: Planting Date Input

Step 5: System Recommendation
Based on research data, show:

Recommended spacing

Estimated maturity period

Fertilizer plan

Expected harvest window

Key management practices

Then confirm and save.

ADD EXISTING CROP FLOW

User selects:

Crop

Variety

Current age in weeks

Any previous activities done

System then generates:

Adjusted timeline

Upcoming activities

Monitoring checklist

CROP DETAIL PAGE

When user clicks a crop card.

Show:

A. Crop Overview

Crop name

Variety

Planting date

Expected harvest date

Growth stage

B. Activity Timeline (Calendar style or vertical timeline)

Show:

Planting

Weeding dates

Fertilizer application dates

Pest control

Irrigation schedule

Expected harvest

C. Task Tracker
Allow farmer to mark tasks as completed.

D. Log Activity Button
Farmer can log:

Date

Activity type

Quantity used

Cost

Notes

LOGBOOK TAB

Purpose: Financial and activity tracking.

Sections:

A. Expense Record

Seeds

Fertilizer

Pesticides

Labour

Transport

Equipment

B. Income Record

Harvest quantity

Selling price

Total revenue

C. Profit Summary
Auto calculated.

D. Activity History
Chronological list of all farm activities.

LIBRARY TAB

Searchable crop knowledge database.

Each crop page contains:

Description

Common varieties

Soil requirements

Climate requirements

Step by step farming guide

Common pests and diseases

Control methods

Search bar must function.

TOOLS TAB

A. Seed Calculator
User inputs:

Farm size

Crop

Spacing

System calculates seed requirement.

B. Pest Identifier (Future AI Integration)
Upload image
Connect to open-source AI
Return likely pest/disease and treatment suggestions.

C. External API Tools (Future)
Weather
Soil data
Research database integration

TECHNICAL REQUIREMENTS

Must store data locally first (local storage)

Should be Docker deployable for testing

API-ready architecture for future AI integration

Clean component structure

Scalable system

DESIGN REQUIREMENTS

Large touch-friendly buttons

Green and earth-tone palette

Minimal icons

Clear typography

Dark mode optional

Card-based UI

Soft rounded corners

Avoid:

Complex animations

Overcrowded screens

Too many features on one page

USER EXPERIENCE PRIORITY

The app must feel:
Simple
Helpful
Trustworthy
Farmer-friendly
Structured
Research-backed