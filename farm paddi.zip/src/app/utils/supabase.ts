import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import type { User, Crop, Activity, Expense, Income } from '../types';

// Create Supabase client singleton
const supabaseUrl = `https://${projectId}.supabase.co`;
const supabase = createClient(supabaseUrl, publicAnonKey);

const API_BASE = `${supabaseUrl}/functions/v1/make-server-240f57ee`;

// Helper to get auth header
const getAuthHeaders = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${session?.access_token || publicAnonKey}`,
  };
};

// ===== AUTH =====

export const auth = {
  // Sign up new user
  signUp: async (userData: {
    email?: string;
    phone?: string;
    password: string;
    fullName: string;
    farmLocation: { state: string; lga: string };
    farmSize: string;
    farmingType: 'Manual' | 'Mechanized';
    farmingMethod: 'Organic' | 'Inorganic' | 'Integrated';
  }) => {
    const response = await fetch(`${API_BASE}/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Signup failed');
    }

    // Now sign in the user
    const loginEmail = userData.email || `${userData.phone}@farmpaddi.app`;
    const { data: authData, error } = await supabase.auth.signInWithPassword({
      email: loginEmail,
      password: userData.password,
    });

    if (error) throw error;
    return authData.user;
  },

  // Sign in existing user
  signIn: async (emailOrPhone: string, password: string) => {
    // Check if it's a phone number (starts with digits)
    const isPhone = /^\d/.test(emailOrPhone);
    const email = isPhone ? `${emailOrPhone}@farmpaddi.app` : emailOrPhone;

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
    return data.user;
  },

  // Sign out
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  // Get current session
  getSession: async () => {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) throw error;
    return session;
  },

  // Get current user profile
  getProfile: async (): Promise<User | null> => {
    const headers = await getAuthHeaders();
    const response = await fetch(`${API_BASE}/user/profile`, { headers });

    if (!response.ok) {
      if (response.status === 401) return null;
      const data = await response.json();
      throw new Error(data.error || 'Failed to get profile');
    }

    const data = await response.json();
    return data.user;
  },

  // Listen to auth state changes
  onAuthStateChange: (callback: (user: any) => void) => {
    return supabase.auth.onAuthStateChange((event, session) => {
      callback(session?.user || null);
    });
  },
};

// ===== CROPS =====

export const crops = {
  // Get all crops for current user
  getAll: async (): Promise<Crop[]> => {
    const headers = await getAuthHeaders();
    const response = await fetch(`${API_BASE}/crops`, { headers });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to get crops');
    }

    const data = await response.json();
    return data.crops || [];
  },

  // Save a crop (create or update)
  save: async (crop: Crop): Promise<Crop> => {
    const headers = await getAuthHeaders();
    const response = await fetch(`${API_BASE}/crops`, {
      method: 'POST',
      headers,
      body: JSON.stringify(crop),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to save crop');
    }

    const data = await response.json();
    return data.crop;
  },

  // Delete a crop
  delete: async (cropId: string): Promise<void> => {
    const headers = await getAuthHeaders();
    const response = await fetch(`${API_BASE}/crops/${cropId}`, {
      method: 'DELETE',
      headers,
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to delete crop');
    }
  },
};

// ===== ACTIVITIES =====

export const activities = {
  // Get all activities (optionally filtered by crop)
  getAll: async (cropId?: string): Promise<Activity[]> => {
    const headers = await getAuthHeaders();
    const url = cropId 
      ? `${API_BASE}/activities?cropId=${cropId}` 
      : `${API_BASE}/activities`;
    
    const response = await fetch(url, { headers });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to get activities');
    }

    const data = await response.json();
    return data.activities || [];
  },

  // Save an activity
  save: async (activity: Activity): Promise<Activity> => {
    const headers = await getAuthHeaders();
    const response = await fetch(`${API_BASE}/activities`, {
      method: 'POST',
      headers,
      body: JSON.stringify(activity),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to save activity');
    }

    const data = await response.json();
    return data.activity;
  },
};

// ===== EXPENSES =====

export const expenses = {
  // Get all expenses (optionally filtered by crop)
  getAll: async (cropId?: string): Promise<Expense[]> => {
    const headers = await getAuthHeaders();
    const url = cropId 
      ? `${API_BASE}/expenses?cropId=${cropId}` 
      : `${API_BASE}/expenses`;
    
    const response = await fetch(url, { headers });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to get expenses');
    }

    const data = await response.json();
    return data.expenses || [];
  },

  // Save an expense
  save: async (expense: Expense): Promise<Expense> => {
    const headers = await getAuthHeaders();
    const response = await fetch(`${API_BASE}/expenses`, {
      method: 'POST',
      headers,
      body: JSON.stringify(expense),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to save expense');
    }

    const data = await response.json();
    return data.expense;
  },
};

// ===== INCOME =====

export const income = {
  // Get all income (optionally filtered by crop)
  getAll: async (cropId?: string): Promise<Income[]> => {
    const headers = await getAuthHeaders();
    const url = cropId 
      ? `${API_BASE}/income?cropId=${cropId}` 
      : `${API_BASE}/income`;
    
    const response = await fetch(url, { headers });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to get income');
    }

    const data = await response.json();
    return data.income || [];
  },

  // Save income
  save: async (incomeData: Income): Promise<Income> => {
    const headers = await getAuthHeaders();
    const response = await fetch(`${API_BASE}/income`, {
      method: 'POST',
      headers,
      body: JSON.stringify(incomeData),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to save income');
    }

    const data = await response.json();
    return data.income;
  },
};

export { supabase };
